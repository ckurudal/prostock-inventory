import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Menu, Bell, LogOut, Sun, Moon, Package, AlertTriangle, ChevronDown, Home, BarChart3, Settings, Users } from "lucide-react";
import { useTheme } from "next-themes";
import { Link } from "wouter";
import type { ProductWithCategory } from "@shared/schema";

export default function Header() {
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [dismissedNotifications, setDismissedNotifications] = useState<string[]>([]);

  // Gerçek bildirim verileri
  const { data: lowStockProducts = [] } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/dashboard/low-stock"],
  });

  const allNotifications = [
    ...lowStockProducts.map(product => ({
      id: `stock-${product.id}`,
      type: "warning" as const,
      title: "Düşük Stok Uyarısı",
      message: `${product.name} - ${product.stock} adet kaldı`,
      time: "Az önce",
      icon: AlertTriangle,
    })),
    {
      id: "system-1",
      type: "info" as const,
      title: "Sistem Bilgisi",
      message: "Bugün 3 yeni satış gerçekleşti",
      time: "1 saat önce",
      icon: Package,
    }
  ];

  const notifications = allNotifications.filter(n => !dismissedNotifications.includes(n.id));

  const handleMarkAllAsRead = () => {
    setDismissedNotifications(allNotifications.map(n => n.id));
    setIsNotificationOpen(false);
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm border-b border-gray-200 dark:border-gray-700 px-4 py-4 lg:px-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <DropdownMenu open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem asChild>
                <Link href="/dashboard" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <Home className="h-4 w-4" />
                  <span>Ana Sayfa</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/products" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <Package className="h-4 w-4" />
                  <span>Ürünler</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/sales" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <Package className="h-4 w-4" />
                  <span>Satış</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/barcode" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <Package className="h-4 w-4" />
                  <span>Barkod</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/reports" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <BarChart3 className="h-4 w-4" />
                  <span>Raporlar</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings" className="flex items-center space-x-2" onClick={() => setIsMobileMenuOpen(false)}>
                  <Settings className="h-4 w-4" />
                  <span>Ayarlar</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="text-red-600 dark:text-red-400">
                <LogOut className="h-4 w-4 mr-2" />
                <span>Çıkış Yap</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">T</span>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto">
                  <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-white">ProStock</h2>
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard" className="flex items-center space-x-2">
                    <Home className="h-4 w-4" />
                    <span>Ana Sayfa</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/reports" className="flex items-center space-x-2">
                    <BarChart3 className="h-4 w-4" />
                    <span>Raporlar</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings" className="flex items-center space-x-2">
                    <Settings className="h-4 w-4" />
                    <span>Ayarlar</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-gray-600 dark:text-gray-400 cursor-default">
                  <Users className="h-4 w-4 mr-2" />
                  <span>Bayii: {user?.name || 'Admin'}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="relative"
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
          
          <Popover open={isNotificationOpen} onOpenChange={setIsNotificationOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="relative"
              >
                <Bell className="h-4 w-4" />
                {notifications.length > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-xs text-white flex items-center justify-center p-0 border-0">
                    {notifications.length}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white">Bildirimler</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {notifications.length} yeni bildirim
                </p>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-gray-500 dark:text-gray-400">
                    <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Henüz bildirim yok</p>
                  </div>
                ) : (
                  <div className="divide-y divide-gray-100 dark:divide-gray-700">
                    {notifications.map((notification) => {
                      const Icon = notification.icon;
                      return (
                        <div key={notification.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                          <div className="flex items-start space-x-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                              notification.type === "warning" 
                                ? "bg-orange-100 dark:bg-orange-900" 
                                : "bg-blue-100 dark:bg-blue-900"
                            }`}>
                              <Icon className={`h-4 w-4 ${
                                notification.type === "warning" 
                                  ? "text-orange-600 dark:text-orange-400" 
                                  : "text-blue-600 dark:text-blue-400"
                              }`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 dark:text-white">
                                {notification.title}
                              </p>
                              <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                                {notification.message}
                              </p>
                              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                                {notification.time}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              {notifications.length > 0 && (
                <div className="p-3 border-t border-gray-200 dark:border-gray-700">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full text-xs"
                    onClick={handleMarkAllAsRead}
                  >
                    Tümünü Okundu Olarak İşaretle
                  </Button>
                </div>
              )}
            </PopoverContent>
          </Popover>
          
          <div className="hidden lg:flex items-center space-x-2 px-3 py-2 bg-green-100 dark:bg-green-900 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-green-700 dark:text-green-300">Çevrimiçi</span>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            title="Çıkış Yap"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
