import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Edit, Trash2, Eye } from "lucide-react";
import type { ProductWithCategory, Category } from "@shared/schema";
import ProductForm from "./product-form";

interface ProductTableProps {
  products: ProductWithCategory[];
  categories: Category[];
  isLoading: boolean;
  onDelete: (id: number) => void;
}

export default function ProductTable({ products, categories, isLoading, onDelete }: ProductTableProps) {
  const [selectedProduct, setSelectedProduct] = useState<ProductWithCategory | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
    }).format(parseFloat(amount));
  };

  const getStockStatus = (product: ProductWithCategory) => {
    if (product.stock <= 0) return { label: "Stokta Yok", variant: "destructive" as const };
    if (product.stock <= product.minStock) return { label: "Düşük Stok", variant: "secondary" as const };
    return { label: "Stokta Var", variant: "default" as const };
  };

  const calculateProfitMargin = (buyPrice: string, sellPrice: string) => {
    const buy = parseFloat(buyPrice);
    const sell = parseFloat(sellPrice);
    return (((sell - buy) / buy) * 100).toFixed(2);
  };

  const handleEdit = (product: ProductWithCategory) => {
    setSelectedProduct(product);
    setIsEditDialogOpen(true);
  };

  const handleView = (product: ProductWithCategory) => {
    setSelectedProduct(product);
    setIsViewDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="h-16 bg-gray-200 rounded-lg"></div>
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">Ürün bulunamadı</p>
        <p className="text-gray-400 text-sm">Arama kriterlerinizi değiştirmeyi deneyin</p>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left p-4 font-medium text-gray-900">Ürün</th>
              <th className="text-left p-4 font-medium text-gray-900">Kategori</th>
              <th className="text-left p-4 font-medium text-gray-900">Barkod</th>
              <th className="text-left p-4 font-medium text-gray-900">Fiyat</th>
              <th className="text-left p-4 font-medium text-gray-900">Stok</th>
              <th className="text-left p-4 font-medium text-gray-900">Kâr Marjı</th>
              <th className="text-right p-4 font-medium text-gray-900">İşlemler</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => {
              const stockStatus = getStockStatus(product);
              return (
                <tr key={product.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="p-4">
                    <div>
                      <h4 className="font-medium text-gray-900">{product.name}</h4>
                      {product.description && (
                        <p className="text-sm text-gray-500 truncate max-w-xs">
                          {product.description}
                        </p>
                      )}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                      {product.category?.name || "-"}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className="font-mono text-sm">{product.barcode}</span>
                  </td>
                  <td className="p-4">
                    <div className="space-y-1">
                      <p className="font-semibold text-green-600">
                        {formatCurrency(product.sellPrice)}
                      </p>
                      <p className="text-xs text-gray-500">
                        Alış: {formatCurrency(product.buyPrice)}
                      </p>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="space-y-1">
                      <Badge variant={stockStatus.variant}>
                        {product.stock} adet
                      </Badge>
                      <p className="text-xs text-gray-500">
                        Min: {product.minStock}
                      </p>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="font-semibold text-purple-600">
                      %{calculateProfitMargin(product.buyPrice, product.sellPrice)}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleView(product)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(product)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Ürünü Sil</AlertDialogTitle>
                            <AlertDialogDescription>
                              "{product.name}" ürününü silmek istediğinizden emin misiniz? 
                              Bu işlem geri alınamaz.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>İptal</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => onDelete(product.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Sil
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Ürün Düzenle</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <ProductForm
              categories={categories}
              product={selectedProduct}
              onSuccess={() => {
                setIsEditDialogOpen(false);
                setSelectedProduct(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Ürün Detayları</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Ürün Adı</label>
                    <p className="text-lg font-semibold">{selectedProduct.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Kategori</label>
                    <p>{selectedProduct.category?.name || "-"}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Barkod</label>
                    <p className="font-mono">{selectedProduct.barcode}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Alış Fiyatı</label>
                    <p className="text-lg">{formatCurrency(selectedProduct.buyPrice)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Satış Fiyatı</label>
                    <p className="text-lg font-semibold text-green-600">
                      {formatCurrency(selectedProduct.sellPrice)}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Kâr Marjı</label>
                    <p className="text-lg font-semibold text-purple-600">
                      %{calculateProfitMargin(selectedProduct.buyPrice, selectedProduct.sellPrice)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Mevcut Stok</label>
                  <div className="flex items-center space-x-2">
                    <p className="text-lg font-semibold">{selectedProduct.stock} adet</p>
                    <Badge variant={getStockStatus(selectedProduct).variant}>
                      {getStockStatus(selectedProduct).label}
                    </Badge>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Minimum Stok</label>
                  <p className="text-lg">{selectedProduct.minStock} adet</p>
                </div>
              </div>

              {selectedProduct.description && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Açıklama</label>
                  <p className="mt-1 p-3 bg-gray-50 rounded-lg">{selectedProduct.description}</p>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Kapat
                </Button>
                <Button
                  onClick={() => {
                    setIsViewDialogOpen(false);
                    handleEdit(selectedProduct);
                  }}
                >
                  Düzenle
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
