import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Shuffle, QrCode } from "lucide-react";
import type { Category, ProductWithCategory } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import BarcodeScanner from "@/components/barcode/scanner";

const productSchema = z.object({
  name: z.string().min(1, "Ürün adı gereklidir"),
  barcode: z.string().min(1, "Barkod gereklidir"),
  categoryId: z.number().min(1, "Kategori seçimi gereklidir"),
  buyPrice: z.string().min(1, "Alış fiyatı gereklidir"),
  sellPrice: z.string().min(1, "Satış fiyatı gereklidir"),
  stock: z.number().min(0, "Stok negatif olamaz"),
  minStock: z.number().min(0, "Minimum stok negatif olamaz"),
  description: z.string().optional(),
});

type ProductFormData = z.infer<typeof productSchema>;

interface ProductFormProps {
  categories: Category[];
  product?: ProductWithCategory;
  onSuccess: () => void;
}

export default function ProductForm({ categories, product, onSuccess }: ProductFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: product?.name || "",
      barcode: product?.barcode || "",
      categoryId: product?.categoryId || 0,
      buyPrice: product?.buyPrice || "",
      sellPrice: product?.sellPrice || "",
      stock: product?.stock || 0,
      minStock: product?.minStock || 5,
      description: product?.description || "",
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: ProductFormData) => {
      const url = product ? `/api/products/${product.id}` : "/api/products";
      const method = product ? "PUT" : "POST";
      
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      
      if (!response.ok) throw new Error("Failed to save product");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Başarılı",
        description: product ? "Ürün başarıyla güncellendi" : "Ürün başarıyla eklendi",
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Ürün kaydedilirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const generateBarcode = () => {
    const timestamp = Date.now().toString();
    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    const barcode = `869${timestamp.slice(-6)}${randomNum}`;
    form.setValue("barcode", barcode);
  };

  const handleBarcodeScanned = (barcode: string) => {
    form.setValue("barcode", barcode);
    setIsScannerOpen(false);
    toast({
      title: "Barkod Tarandı",
      description: `Barkod: ${barcode}`,
    });
  };

  const onSubmit = (data: ProductFormData) => {
    setIsLoading(true);
    createProductMutation.mutate(data);
    setIsLoading(false);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Ürün Adı *</FormLabel>
                <FormControl>
                  <Input placeholder="Ürün adını girin" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="categoryId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Kategori *</FormLabel>
                <Select
                  value={field.value.toString()}
                  onValueChange={(value) => field.onChange(parseInt(value))}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Kategori seçin" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="barcode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Barkod *</FormLabel>
              <div className="flex space-x-2">
                <FormControl>
                  <Input placeholder="Barkod numarası" {...field} />
                </FormControl>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsScannerOpen(true)}
                  disabled={isLoading}
                >
                  <QrCode className="h-4 w-4 mr-2" />
                  Tara
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={generateBarcode}
                  disabled={isLoading}
                >
                  <Shuffle className="h-4 w-4 mr-2" />
                  Oluştur
                </Button>
              </div>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="buyPrice"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Alış Fiyatı (₺) *</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="sellPrice"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Satış Fiyatı (₺) *</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="stock"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Stok Miktarı</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="0"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="minStock"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Minimum Stok</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="5"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Açıklama</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Ürün açıklaması (isteğe bağlı)"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Profit Margin Display */}
        {form.watch("buyPrice") && form.watch("sellPrice") && (
          <div className="p-4 bg-blue-50 rounded-lg">
            <Label className="text-sm font-medium text-blue-800">Kâr Marjı</Label>
            <p className="text-lg font-bold text-blue-900">
              %{(((parseFloat(form.watch("sellPrice")) - parseFloat(form.watch("buyPrice"))) / parseFloat(form.watch("buyPrice"))) * 100).toFixed(2)}
            </p>
            <p className="text-sm text-blue-700">
              Birim Kâr: ₺{(parseFloat(form.watch("sellPrice")) - parseFloat(form.watch("buyPrice"))).toFixed(2)}
            </p>
          </div>
        )}

        <div className="flex justify-end space-x-3">
          <Button type="button" variant="outline" onClick={onSuccess}>
            İptal
          </Button>
          <Button
            type="submit"
            disabled={isLoading || createProductMutation.isPending}
            className="bg-primary hover:bg-primary/90"
          >
            {isLoading || createProductMutation.isPending
              ? "Kaydediliyor..."
              : product
              ? "Güncelle"
              : "Kaydet"
            }
          </Button>
        </div>
      </form>

      {/* Barkod Tarayıcı Dialog */}
      <Dialog open={isScannerOpen} onOpenChange={setIsScannerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Barkod Tarama</DialogTitle>
          </DialogHeader>
          <BarcodeScanner
            onScan={handleBarcodeScanned}
            onClose={() => setIsScannerOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </Form>
  );
}
