import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Camera, Keyboard, X } from "lucide-react";

interface BarcodeScannerProps {
  onScan: (barcode: string) => void;
  onClose: () => void;
}

export default function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [manualBarcode, setManualBarcode] = useState("");
  const [error, setError] = useState("");
  const [useManualEntry, setUseManualEntry] = useState(false);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      setError("");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment", // Use back camera on mobile
          width: { ideal: 640 },
          height: { ideal: 480 }
        }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setIsScanning(true);
        
        // Start scanning loop
        startScanningLoop();
      }
    } catch (err) {
      setError("Kamera erişimi reddedildi. Manuel giriş kullanın.");
      setUseManualEntry(true);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
  };

  const startScanningLoop = () => {
    // In a real implementation, you would use a barcode scanning library like QuaggaJS
    // For now, we'll simulate the scanning interface
    const scanInterval = setInterval(() => {
      if (!isScanning || !videoRef.current || !canvasRef.current) {
        clearInterval(scanInterval);
        return;
      }
      
      // Simulate barcode detection (in real app, use QuaggaJS or similar)
      // This would capture frame and process it for barcodes
    }, 100);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualBarcode.trim()) {
      onScan(manualBarcode.trim());
    }
  };

  if (useManualEntry) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Manuel Barkod Girişi</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <form onSubmit={handleManualSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="manual-barcode">Barkod Numarası</Label>
            <Input
              id="manual-barcode"
              value={manualBarcode}
              onChange={(e) => setManualBarcode(e.target.value)}
              placeholder="Barkod numarasını girin"
              autoFocus
            />
          </div>
          
          <div className="flex space-x-2">
            <Button type="submit" className="flex-1">
              <Keyboard className="h-4 w-4 mr-2" />
              Ara
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setUseManualEntry(false)}
            >
              <Camera className="h-4 w-4 mr-2" />
              Kamera
            </Button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Barkod Okutma</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}
      
      <div className="relative bg-gray-900 rounded-lg overflow-hidden" style={{ aspectRatio: "4/3" }}>
        {isScanning ? (
          <>
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              playsInline
              muted
            />
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full"
              style={{ display: "none" }}
            />
            
            {/* Scanning overlay */}
            <div className="absolute inset-4 border-2 border-primary rounded-lg pointer-events-none">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-0.5 bg-primary opacity-75 scanner-line"></div>
              </div>
            </div>
            
            {/* Instructions */}
            <div className="absolute bottom-4 left-4 right-4 text-center">
              <p className="text-white text-sm bg-black bg-opacity-50 px-3 py-2 rounded">
                Barkodu çerçeveye hizalayın
              </p>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-white">
            <div className="text-center">
              <Camera className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm opacity-75">Kamerayı başlatın</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="space-y-3">
        {!isScanning ? (
          <Button
            onClick={startCamera}
            className="w-full bg-primary hover:bg-primary/90"
          >
            <Camera className="h-4 w-4 mr-2" />
            Kamerayı Başlat
          </Button>
        ) : (
          <Button
            onClick={stopCamera}
            variant="outline"
            className="w-full"
          >
            Kamerayı Durdur
          </Button>
        )}
        
        <Separator />
        
        <Button
          variant="outline"
          className="w-full"
          onClick={() => setUseManualEntry(true)}
        >
          <Keyboard className="h-4 w-4 mr-2" />
          Manuel Giriş
        </Button>
      </div>
    </div>
  );
}
