import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Printer, Download } from "lucide-react";
import type { ProductWithCategory } from "@shared/schema";
import { generateBarcode } from "@/lib/barcode";

interface BarcodeGeneratorProps {
  products: ProductWithCategory[];
  selectedProduct?: ProductWithCategory | null;
}

export default function BarcodeGenerator({ products, selectedProduct }: BarcodeGeneratorProps) {
  const [selectedProductId, setSelectedProductId] = useState<string>(
    selectedProduct?.id.toString() || ""
  );
  const [barcodeFormat, setBarcodeFormat] = useState("CODE128");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const currentProduct = products.find(p => p.id.toString() === selectedProductId);

  const generateBarcodeImage = () => {
    if (!currentProduct || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Generate barcode using the utility function
    generateBarcode(currentProduct.barcode, canvas, barcodeFormat);
  };

  const handlePrint = () => {
    if (!currentProduct) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    const canvas = canvasRef.current;
    const barcodeDataUrl = canvas?.toDataURL() || "";

    printWindow.document.write(`
      <html>
        <head>
          <title>Barkod Etiket - ${currentProduct.name}</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              margin: 0; 
              padding: 20px;
              text-align: center;
            }
            .label {
              border: 1px solid #000;
              padding: 10px;
              margin: 10px auto;
              width: 300px;
              display: inline-block;
            }
            .product-name {
              font-size: 12px;
              font-weight: bold;
              margin-bottom: 5px;
            }
            .barcode {
              margin: 10px 0;
            }
            .barcode-number {
              font-family: monospace;
              font-size: 10px;
              margin-top: 5px;
            }
            .price {
              font-size: 14px;
              font-weight: bold;
              margin-top: 5px;
            }
            @media print {
              body { margin: 0; padding: 0; }
              .label { margin: 0; page-break-after: always; }
            }
          </style>
        </head>
        <body>
          <div class="label">
            <div class="product-name">${currentProduct.name}</div>
            <div class="barcode">
              <img src="${barcodeDataUrl}" alt="Barcode" style="max-width: 100%;">
            </div>
            <div class="barcode-number">${currentProduct.barcode}</div>
            <div class="price">₺${currentProduct.sellPrice}</div>
          </div>
          <script>
            window.onload = function() {
              window.print();
              window.close();
            }
          </script>
        </body>
      </html>
    `);
  };

  const handleDownload = () => {
    if (!currentProduct || !canvasRef.current) return;

    const link = document.createElement("a");
    link.download = `barcode-${currentProduct.barcode}.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Settings */}
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Ürün Seçin</Label>
            <Select value={selectedProductId} onValueChange={setSelectedProductId}>
              <SelectTrigger>
                <SelectValue placeholder="Ürün seçin..." />
              </SelectTrigger>
              <SelectContent>
                {products.map((product) => (
                  <SelectItem key={product.id} value={product.id.toString()}>
                    {product.name} - {product.barcode}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Barkod Formatı</Label>
            <Select value={barcodeFormat} onValueChange={setBarcodeFormat}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="CODE128">CODE128</SelectItem>
                <SelectItem value="EAN13">EAN13</SelectItem>
                <SelectItem value="CODE39">CODE39</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={generateBarcodeImage}
            className="w-full"
            disabled={!currentProduct}
          >
            Barkod Oluştur
          </Button>
        </div>

        {/* Product Info */}
        {currentProduct && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ürün Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-sm text-gray-600">Ürün Adı</Label>
                <p className="font-medium">{currentProduct.name}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-600">Barkod</Label>
                <p className="font-mono text-sm">{currentProduct.barcode}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-600">Kategori</Label>
                <p className="text-sm">{currentProduct.category?.name || "-"}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-600">Satış Fiyatı</Label>
                <p className="text-lg font-bold text-green-600">₺{currentProduct.sellPrice}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-600">Stok</Label>
                <p className="text-sm">{currentProduct.stock} adet</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Barcode Preview */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Barkod Önizleme</CardTitle>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              disabled={!currentProduct}
            >
              <Download className="h-4 w-4 mr-2" />
              İndir
            </Button>
            <Button
              size="sm"
              onClick={handlePrint}
              disabled={!currentProduct}
            >
              <Printer className="h-4 w-4 mr-2" />
              Yazdır
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center p-6 bg-gray-50 rounded-lg">
            <div className="text-center">
              <canvas
                ref={canvasRef}
                className="border border-gray-300 bg-white"
                width={300}
                height={100}
              />
              {currentProduct && (
                <div className="mt-4 space-y-1">
                  <p className="font-medium text-sm">{currentProduct.name}</p>
                  <p className="font-mono text-xs text-gray-600">{currentProduct.barcode}</p>
                  <p className="font-bold text-green-600">₺{currentProduct.sellPrice}</p>
                </div>
              )}
            </div>
          </div>
          
          {!currentProduct && (
            <div className="text-center py-8 text-gray-500">
              <p>Barkod oluşturmak için ürün seçin</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
