import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { format, startOfDay, startOfWeek, startOfMonth, eachDayOfInterval, eachWeekOfInterval, eachMonthOfInterval } from "date-fns";
import { tr } from "date-fns/locale";
import type { SaleWithItems } from "@shared/schema";

interface ReportChartProps {
  sales: SaleWithItems[];
  type: "daily" | "weekly" | "monthly";
}

export default function ReportChart({ sales, type }: ReportChartProps) {
  const chartData = useMemo(() => {
    if (!sales.length) return [];

    const now = new Date();
    let intervals: Date[] = [];
    let formatString = "";

    switch (type) {
      case "daily":
        intervals = eachDayOfInterval({
          start: new Date(now.getFullYear(), now.getMonth(), 1),
          end: now,
        });
        formatString = "dd MMM";
        break;
      case "weekly":
        intervals = eachWeekOfInterval({
          start: new Date(now.getFullYear(), now.getMonth() - 2, 1),
          end: now,
        }, { locale: tr });
        formatString = "dd MMM";
        break;
      case "monthly":
        intervals = eachMonthOfInterval({
          start: new Date(now.getFullYear() - 1, 0, 1),
          end: now,
        });
        formatString = "MMM yyyy";
        break;
    }

    return intervals.map(interval => {
      const startDate = type === "daily" ? startOfDay(interval) :
                       type === "weekly" ? startOfWeek(interval, { locale: tr }) :
                       startOfMonth(interval);
      
      const endDate = type === "daily" ? new Date(startDate.getTime() + 24 * 60 * 60 * 1000 - 1) :
                     type === "weekly" ? new Date(startDate.getTime() + 7 * 24 * 60 * 60 * 1000 - 1) :
                     new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0, 23, 59, 59);

      const periodSales = sales.filter(sale => {
        const saleDate = new Date(sale.createdAt!);
        return saleDate >= startDate && saleDate <= endDate;
      });

      const revenue = periodSales.reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);
      const salesCount = periodSales.length;

      return {
        period: format(interval, formatString, { locale: tr }),
        revenue,
        salesCount,
        averageSale: salesCount > 0 ? revenue / salesCount : 0,
      };
    });
  }, [sales, type]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900 mb-2">{label}</p>
          <div className="space-y-1">
            <p className="text-sm text-blue-600">
              Gelir: {formatCurrency(payload[0]?.value || 0)}
            </p>
            <p className="text-sm text-green-600">
              Satış: {payload[1]?.value || 0} adet
            </p>
            <p className="text-sm text-purple-600">
              Ortalama: {formatCurrency(payload[2]?.value || 0)}
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  if (!chartData.length) {
    return (
      <div className="h-64 flex items-center justify-center text-gray-500">
        <div className="text-center">
          <p>Gösterilecek veri yok</p>
          <p className="text-sm mt-1">Seçilen dönemde satış bulunamadı</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Revenue Chart */}
      <div className="bg-white p-4 rounded-lg border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Gelir Grafiği</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="period" 
              tick={{ fontSize: 12 }}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar 
              dataKey="revenue" 
              fill="hsl(var(--primary))" 
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Sales Count and Average */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Satış Adedi</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="period" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                labelStyle={{ color: '#000' }}
                formatter={(value: number) => [value, 'Satış Adedi']}
              />
              <Line 
                type="monotone" 
                dataKey="salesCount" 
                stroke="#10b981" 
                strokeWidth={3}
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-4 rounded-lg border">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Ortalama Satış</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="period" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                tickFormatter={formatCurrency}
              />
              <Tooltip 
                labelStyle={{ color: '#000' }}
                formatter={(value: number) => [formatCurrency(value), 'Ortalama Satış']}
              />
              <Line 
                type="monotone" 
                dataKey="averageSale" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
