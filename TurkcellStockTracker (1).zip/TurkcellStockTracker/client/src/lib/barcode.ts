export interface BarcodeOptions {
  format: string;
  width: number;
  height: number;
  displayValue: boolean;
  fontSize: number;
  textMargin: number;
}

export function generateBarcode(
  text: string,
  canvas: HTMLCanvasElement,
  format: string = "CODE128"
): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  // Clear canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Simple barcode representation (in a real app, use a proper barcode library)
  const barWidth = 2;
  const barHeight = 60;
  const startX = 20;
  const startY = 20;

  // Generate simple pattern based on text
  ctx.fillStyle = "black";
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    const pattern = charCode % 4; // Simple pattern generation
    
    for (let j = 0; j < 4; j++) {
      if ((pattern >> j) & 1) {
        const x = startX + (i * 4 + j) * barWidth;
        ctx.fillRect(x, startY, barWidth, barHeight);
      }
    }
  }

  // Add text below barcode
  ctx.fillStyle = "black";
  ctx.font = "12px monospace";
  ctx.textAlign = "center";
  ctx.fillText(text, canvas.width / 2, startY + barHeight + 20);
}

export function validateBarcode(barcode: string, format: string): boolean {
  if (!barcode || barcode.trim().length === 0) return false;

  switch (format) {
    case "CODE128":
      return /^[\x00-\x7F]+$/.test(barcode) && barcode.length >= 1;
    case "EAN13":
      return /^\d{13}$/.test(barcode);
    case "CODE39":
      return /^[A-Z0-9\-. $/+%]+$/.test(barcode);
    default:
      return true;
  }
}

export function generateRandomBarcode(): string {
  const timestamp = Date.now().toString();
  const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
  return `869${timestamp.slice(-6)}${randomNum}`;
}

export function formatBarcodeForDisplay(barcode: string): string {
  // Add spaces for better readability
  return barcode.replace(/(.{4})/g, "$1 ").trim();
}
