import * as XLSX from "xlsx";
import jsPDF from "jspdf";

export function exportToExcel(data: any[], filename: string): void {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
  
  // Auto-size columns
  const maxWidth = data.reduce((w, r) => Math.max(w, Object.keys(r).length), 10);
  worksheet["!cols"] = Array(maxWidth).fill({ wch: 20 });
  
  XLSX.writeFile(workbook, `${filename}.xlsx`);
}

export function exportToPDF(reportData: {
  title: string;
  period: string;
  summary: {
    totalSales: number;
    totalRevenue: number;
    averageSale: number;
  };
  details: Array<{
    id: number;
    date: string;
    amount: number;
    items: number;
  }>;
}): void {
  const doc = new jsPDF();
  
  // Set font for Turkish characters
  doc.setFont("helvetica");
  
  // Title
  doc.setFontSize(20);
  doc.text(reportData.title, 20, 20);
  
  // Period
  doc.setFontSize(12);
  doc.text(`Dönem: ${reportData.period}`, 20, 35);
  
  // Summary section
  doc.setFontSize(14);
  doc.text("ÖZET", 20, 55);
  
  doc.setFontSize(10);
  let yPos = 70;
  doc.text(`Toplam Satış: ${reportData.summary.totalSales}`, 20, yPos);
  yPos += 10;
  doc.text(`Toplam Gelir: ₺${reportData.summary.totalRevenue.toFixed(2)}`, 20, yPos);
  yPos += 10;
  doc.text(`Ortalama Satış: ₺${reportData.summary.averageSale.toFixed(2)}`, 20, yPos);
  yPos += 20;
  
  // Details section
  doc.setFontSize(14);
  doc.text("DETAYLAR", 20, yPos);
  yPos += 15;
  
  // Table headers
  doc.setFontSize(10);
  doc.text("Satış No", 20, yPos);
  doc.text("Tarih", 60, yPos);
  doc.text("Tutar", 120, yPos);
  doc.text("Ürün", 160, yPos);
  yPos += 10;
  
  // Table rows
  reportData.details.forEach((detail) => {
    if (yPos > 270) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.text(`#${detail.id}`, 20, yPos);
    doc.text(detail.date, 60, yPos);
    doc.text(`₺${detail.amount.toFixed(2)}`, 120, yPos);
    doc.text(`${detail.items}`, 160, yPos);
    yPos += 8;
  });
  
  // Add footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text(
      `Sayfa ${i} / ${pageCount} - Türkcell Bayii Stok Takip Sistemi`,
      20,
      285
    );
  }
  
  doc.save(`${reportData.title.toLowerCase().replace(/\s+/g, "-")}.pdf`);
}

export function exportProductsToExcel(products: any[]): void {
  const exportData = products.map(product => ({
    "Ürün Adı": product.name,
    "Barkod": product.barcode,
    "Kategori": product.category?.name || "-",
    "Alış Fiyatı": `₺${product.buyPrice}`,
    "Satış Fiyatı": `₺${product.sellPrice}`,
    "Stok": product.stock,
    "Min. Stok": product.minStock,
    "Kâr Marjı": `%${(((parseFloat(product.sellPrice) - parseFloat(product.buyPrice)) / parseFloat(product.buyPrice)) * 100).toFixed(2)}`,
    "Açıklama": product.description || "-",
  }));

  exportToExcel(exportData, "urunler");
}

export function exportSalesToExcel(sales: any[]): void {
  const exportData = sales.map(sale => ({
    "Satış No": sale.id,
    "Tarih": new Date(sale.createdAt).toLocaleString("tr-TR"),
    "Toplam Tutar": `₺${sale.totalAmount}`,
    "KDV": `₺${sale.taxAmount}`,
    "Ödeme Yöntemi": sale.paymentMethod === "cash" ? "Nakit" : sale.paymentMethod === "card" ? "Kart" : "Transfer",
    "Ürün Sayısı": sale.items?.length || 0,
    "Satıcı": sale.user?.name || "Bilinmiyor",
  }));

  exportToExcel(exportData, `satis-raporu-${new Date().toISOString().split('T')[0]}`);
}
