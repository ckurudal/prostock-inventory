import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Building, 
  DollarSign, 
  Download, 
  Upload,
  Save,
  RefreshCw
} from "lucide-react";
import type { Setting } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";

export default function Settings() {
  const [companyName, setCompanyName] = useState("");
  const [currency, setCurrency] = useState("TL");
  const [taxRate, setTaxRate] = useState("20");
  const [lowStockThreshold, setLowStockThreshold] = useState("5");
  const { toast } = useToast();

  const { data: settings = [], isLoading } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
    onSuccess: (data) => {
      data.forEach(setting => {
        switch (setting.key) {
          case "company_name":
            setCompanyName(setting.value);
            break;
          case "currency":
            setCurrency(setting.value);
            break;
          case "tax_rate":
            setTaxRate(setting.value);
            break;
          case "low_stock_threshold":
            setLowStockThreshold(setting.value);
            break;
        }
      });
    },
  });

  const updateSettingMutation = useMutation({
    mutationFn: async (setting: { key: string; value: string; type: string }) => {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(setting),
      });
      if (!response.ok) throw new Error("Failed to update setting");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Başarılı",
        description: "Ayarlar başarıyla güncellendi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Ayarlar güncellenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const saveSettings = () => {
    const settingsToUpdate = [
      { key: "company_name", value: companyName, type: "string" },
      { key: "currency", value: currency, type: "string" },
      { key: "tax_rate", value: taxRate, type: "number" },
      { key: "low_stock_threshold", value: lowStockThreshold, type: "number" },
    ];

    settingsToUpdate.forEach(setting => {
      updateSettingMutation.mutate(setting);
    });
  };

  const handleBackup = () => {
    window.open("/api/backup/export", "_blank");
    toast({
      title: "Başarılı",
      description: "Yedek dosyası indiriliyor...",
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const backup = JSON.parse(e.target?.result as string);
        console.log("Backup data:", backup);
        toast({
          title: "Bilgi",
          description: "Veri geri yükleme özelliği geliştiriliyor...",
        });
      } catch (error) {
        toast({
          title: "Hata",
          description: "Geçersiz yedek dosyası",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Ayarlar</h2>
        <p className="text-gray-600">Sistem ayarlarını yapılandırın</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Company Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Building className="h-5 w-5" />
              <span>İşletme Bilgileri</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">İşletme Adı</Label>
              <Input
                id="companyName"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="İşletme adınızı girin"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Para Birimi</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="TRY">Türk Lirası (₺)</SelectItem>
                  <SelectItem value="USD">Amerikan Doları ($)</SelectItem>
                  <SelectItem value="EUR">Euro (€)</SelectItem>
                  <SelectItem value="GBP">İngiliz Sterlini (£)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Financial Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5" />
              <span>Mali Ayarlar</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="taxRate">KDV Oranı (%)</Label>
              <Select value={taxRate} onValueChange={setTaxRate}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">%0</SelectItem>
                  <SelectItem value="8">%8</SelectItem>
                  <SelectItem value="18">%18</SelectItem>
                  <SelectItem value="20">%20</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="lowStockThreshold">Düşük Stok Limiti</Label>
              <Input
                id="lowStockThreshold"
                type="number"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                placeholder="Minimum stok miktarı"
                min="0"
              />
              <p className="text-sm text-gray-500">
                Bu değerin altındaki ürünler düşük stok olarak işaretlenir
              </p>
            </div>
          </CardContent>
        </Card>

        {/* System Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <SettingsIcon className="h-5 w-5" />
              <span>Sistem İşlemleri</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={saveSettings}
              disabled={updateSettingMutation.isPending}
            >
              <Save className="h-4 w-4 mr-2" />
              {updateSettingMutation.isPending ? "Kaydediliyor..." : "Ayarları Kaydet"}
            </Button>

            <Separator />

            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={handleBackup}
            >
              <Download className="h-4 w-4 mr-2" />
              Veri Yedekle
            </Button>

            <div className="space-y-2">
              <Label htmlFor="restore">Veri Geri Yükle</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="restore"
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById("restore")?.click()}
                  className="w-full justify-start"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Dosya Seç
                </Button>
              </div>
              <p className="text-sm text-gray-500">
                Sadece sistem tarafından oluşturulan yedek dosyalarını yükleyin
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Current Settings Display */}
        <Card>
          <CardHeader>
            <CardTitle>Mevcut Ayarlar</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-1/3 mb-2"></div>
                    <div className="h-6 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {settings.map((setting) => (
                  <div key={setting.key} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">
                        {setting.key === "company_name" && "İşletme Adı"}
                        {setting.key === "currency" && "Para Birimi"}
                        {setting.key === "tax_rate" && "KDV Oranı"}
                        {setting.key === "low_stock_threshold" && "Düşük Stok Limiti"}
                      </p>
                      <p className="text-sm text-gray-600">{setting.key}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">
                        {setting.value}
                        {setting.key === "tax_rate" && "%"}
                        {setting.key === "currency" && setting.value === "TL" && " ₺"}
                      </p>
                      <p className="text-xs text-gray-500">{setting.type}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* About Section */}
      <Card>
        <CardHeader>
          <CardTitle>Sistem Bilgileri</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-2">
                <SettingsIcon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-semibold text-gray-900">Türkcell Bayii</h3>
              <p className="text-sm text-gray-600">Stok Takip Sistemi</p>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                <RefreshCw className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">Versiyon</h3>
              <p className="text-sm text-gray-600">v1.0.0</p>
            </div>
            
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Building className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">Lisans</h3>
              <p className="text-sm text-gray-600">Türkcell Partner</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
