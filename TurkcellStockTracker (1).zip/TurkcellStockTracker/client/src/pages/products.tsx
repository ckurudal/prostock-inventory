import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Package, Download, FolderOpen } from "lucide-react";
import type { ProductWithCategory, Category } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import ProductForm from "@/components/products/product-form";
import ProductTable from "@/components/products/product-table";
import CategoryTable from "@/components/categories/category-table";
import { exportToExcel } from "@/lib/export";
import { useLocation } from "wouter";

export default function Products() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { toast } = useToast();
  const [location] = useLocation();
  
  // URL parametrelerinden düşük stok filtresini kontrol et
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    if (urlParams.get('filter') === 'low-stock') {
      setCategoryFilter('low-stock');
    }
  }, [location]);

  const { data: products = [], isLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/products/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to delete product");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Başarılı",
        description: "Ürün başarıyla silindi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Ürün silinirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const filteredProducts = products.filter((product) => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.barcode.includes(searchTerm) ||
      product.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = 
      categoryFilter === "all" || 
      categoryFilter === "low-stock" ||
      product.categoryId?.toString() === categoryFilter;
      
    const matchesLowStock = 
      categoryFilter !== "low-stock" || 
      product.stock <= product.minStock;

    return matchesSearch && matchesCategory && matchesLowStock;
  });

  const handleExportExcel = () => {
    const exportData = filteredProducts.map(product => ({
      "Ürün Adı": product.name,
      "Barkod": product.barcode,
      "Kategori": product.category?.name || "-",
      "Alış Fiyatı": `₺${product.buyPrice}`,
      "Satış Fiyatı": `₺${product.sellPrice}`,
      "Stok": product.stock,
      "Min. Stok": product.minStock,
      "Kâr Marjı": `%${(((parseFloat(product.sellPrice) - parseFloat(product.buyPrice)) / parseFloat(product.buyPrice)) * 100).toFixed(2)}`,
      "Açıklama": product.description || "-",
    }));

    exportToExcel(exportData, "urunler");
    toast({
      title: "Başarılı",
      description: "Ürünler Excel olarak dışa aktarıldı",
    });
  };

  const getStockStatus = (product: ProductWithCategory) => {
    if (product.stock <= 0) return { label: "Stokta Yok", variant: "destructive" as const };
    if (product.stock <= product.minStock) return { label: "Düşük Stok", variant: "secondary" as const };
    return { label: "Stokta Var", variant: "default" as const };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Ürün ve Kategori Yönetimi</h2>
        <p className="text-gray-600">Ürünlerinizi ve kategorilerinizi yönetin</p>
      </div>

      <Tabs defaultValue="products" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="products" className="flex items-center space-x-2">
            <Package className="h-4 w-4" />
            <span>Ürünler</span>
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center space-x-2">
            <FolderOpen className="h-4 w-4" />
            <span>Kategoriler</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-6">
          {/* Products Header */}
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Ürünler</h3>
              <p className="text-gray-600">Ürün envanterinizi yönetin</p>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" onClick={handleExportExcel}>
                <Download className="h-4 w-4 mr-2" />
                Excel'e Aktar
              </Button>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90">
                    <Plus className="h-4 w-4 mr-2" />
                    Ürün Ekle
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Yeni Ürün Ekle</DialogTitle>
                  </DialogHeader>
                  <ProductForm
                    categories={categories}
                    onSuccess={() => setIsAddDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Toplam Ürün</p>
                <p className="text-xl font-bold">{products.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Stokta Var</p>
                <p className="text-xl font-bold">
                  {products.filter(p => p.stock > p.minStock).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Düşük Stok</p>
                <p className="text-xl font-bold">
                  {products.filter(p => p.stock <= p.minStock && p.stock > 0).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-8 w-8 text-red-600" />
              <div>
                <p className="text-sm text-gray-600">Stokta Yok</p>
                <p className="text-xl font-bold">
                  {products.filter(p => p.stock <= 0).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Ürün adı, barkod veya açıklama ile arama yapın..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Kategori seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Kategoriler</SelectItem>
                <SelectItem value="low-stock">🔻 Düşük Stok</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

          {/* Products Table */}
          <Card>
            <CardHeader>
              <CardTitle>
                Ürünler ({filteredProducts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProductTable
                products={filteredProducts}
                categories={categories}
                isLoading={isLoading}
                onDelete={(id) => deleteProductMutation.mutate(id)}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <CategoryTable
            categories={categories}
            isLoading={isLoading}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
