import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Box, 
  TrendingUp, 
  AlertTriangle, 
  DollarSign,
  Barcode,
  Plus,
  BarChart3,
  Download,
  ChevronRight,
  Clock
} from "lucide-react";
import type { DashboardStats, RecentSale, ProductWithCategory, Setting, ExpenseStats, UpcomingExpense } from "@shared/schema";
import { useLocation } from "wouter";
import { formatCurrency } from "@/lib/currency";

export default function Dashboard() {
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: recentSales, isLoading: salesLoading } = useQuery<RecentSale[]>({
    queryKey: ["/api/dashboard/recent-sales"],
  });

  const { data: lowStockProducts, isLoading: lowStockLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/dashboard/low-stock"],
  });

  const { data: settings = [] } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });

  const { data: expenseStats } = useQuery<ExpenseStats>({
    queryKey: ["/api/expenses/stats"],
  });

  const { data: upcomingExpenses = [] } = useQuery<UpcomingExpense[]>({
    queryKey: ["/api/expenses/upcoming"],
  });

  const currentCurrency = settings.find(s => s.key === "currency")?.value || "TRY";

  const formatCurrencyValue = (amount: number) => {
    return formatCurrency(amount, currentCurrency);
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('tr-TR', {
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(date));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600">Stok takip ve satış yönetimi</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Toplam Ürün</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statsLoading ? "..." : stats?.totalProducts.toLocaleString('tr-TR')}
                </p>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Aktif ürünler
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Box className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Stok Değeri</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statsLoading ? "..." : formatCurrencyValue(stats?.stockValue || 0)}
                </p>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Toplam envanter
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setLocation('/products?filter=low-stock')}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Düşük Stok</p>
                <p className="text-2xl font-bold text-red-600">
                  {statsLoading ? "..." : stats?.lowStockCount}
                </p>
                <p className="text-xs text-red-600 mt-1 flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Dikkat gerekli
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Günlük Ciro</p>
                <p className="text-2xl font-bold text-gray-900">
                  {statsLoading ? "..." : formatCurrencyValue(stats?.dailyRevenue || 0)}
                </p>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Bugünkü satışlar
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Expense Stats Cards */}
      {expenseStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setLocation('/expenses')}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Aylık Giderler</p>
                  <p className="text-2xl font-bold text-red-600">
                    {formatCurrencyValue(expenseStats.totalMonthlyExpenses)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Bu ay toplam</p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setLocation('/expenses')}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Bekleyen Ödemeler</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {expenseStats.pendingPayments}
                  </p>
                  <p className="text-xs text-yellow-600 mt-1 flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    Ödenmedi
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Clock className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setLocation('/expenses')}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Geciken Ödemeler</p>
                  <p className="text-2xl font-bold text-red-600">
                    {expenseStats.overduePayments}
                  </p>
                  <p className="text-xs text-red-600 mt-1 flex items-center">
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Gecikmiş
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setLocation('/expenses')}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Yıllık Giderler</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {formatCurrencyValue(expenseStats.totalYearlyExpenses)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Bu yıl toplam</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Upcoming Expenses Alert */}
      {upcomingExpenses.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-800 flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Yaklaşan Ödemeler (7 Gün İçinde)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingExpenses.slice(0, 3).map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 bg-white rounded border">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: expense.categoryColor || '#6B7280' }}
                    />
                    <div>
                      <p className="font-medium text-gray-900">{expense.title}</p>
                      <p className="text-sm text-gray-500">{expense.categoryName}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">{formatCurrency(expense.amount)}</p>
                    <p className="text-sm text-orange-600">
                      {expense.daysUntilDue} gün kaldı
                    </p>
                  </div>
                </div>
              ))}
              {upcomingExpenses.length > 3 && (
                <Button
                  variant="outline"
                  onClick={() => setLocation('/expenses')}
                  className="w-full mt-3"
                >
                  {upcomingExpenses.length - 3} tane daha gör
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Hızlı İşlemler</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4"
              onClick={() => setLocation("/barcode")}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Barcode className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="font-medium">Barkod Oku</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4"
              onClick={() => setLocation("/products")}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                  <Plus className="h-4 w-4 text-white" />
                </div>
                <span className="font-medium">Ürün Ekle</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4"
              onClick={() => setLocation("/expenses")}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-4 w-4 text-white" />
                </div>
                <span className="font-medium">Gider Yönetimi</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4"
              onClick={() => setLocation("/reports")}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-4 w-4 text-white" />
                </div>
                <span className="font-medium">Raporları Gör</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>

            <Button
              variant="outline"
              className="w-full justify-between h-auto p-4"
              onClick={() => window.open("/api/backup/export", "_blank")}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                  <Download className="h-4 w-4 text-white" />
                </div>
                <span className="font-medium">Yedekle</span>
              </div>
              <ChevronRight className="h-4 w-4 text-gray-400" />
            </Button>
          </CardContent>
        </Card>

        {/* Recent Sales */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Son Satışlar</CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation("/sales")}
            >
              Tümünü Gör
            </Button>
          </CardHeader>
          <CardContent>
            {salesLoading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center justify-between p-4 bg-gray-100 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-300 rounded-lg"></div>
                        <div className="space-y-2">
                          <div className="w-32 h-4 bg-gray-300 rounded"></div>
                          <div className="w-20 h-3 bg-gray-300 rounded"></div>
                        </div>
                      </div>
                      <div className="text-right space-y-2">
                        <div className="w-16 h-4 bg-gray-300 rounded"></div>
                        <div className="w-12 h-3 bg-gray-300 rounded"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {recentSales?.slice(0, 4).map((sale) => (
                  <div key={sale.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Box className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{sale.productName}</p>
                        <p className="text-sm text-gray-500 flex items-center">
                          {sale.quantity} adet • <Clock className="h-3 w-3 mx-1" /> {formatTime(sale.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">{formatCurrency(sale.totalPrice)}</p>
                      <p className="text-xs text-green-600">+{formatCurrency(sale.profit)} kâr</p>
                    </div>
                  </div>
                ))}
                {recentSales?.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Box className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>Henüz satış kaydı yok</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Low Stock Alert */}
      {(lowStockProducts?.length || 0) > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <CardTitle>Düşük Stok Uyarısı</CardTitle>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation("/products")}
            >
              Tümünü Gör
            </Button>
          </CardHeader>
          <CardContent>
            {lowStockLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse p-4 border border-gray-200 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-32 h-4 bg-gray-300 rounded"></div>
                      <div className="w-16 h-6 bg-gray-300 rounded-full"></div>
                    </div>
                    <div className="w-24 h-3 bg-gray-300 rounded mb-3"></div>
                    <div className="w-full h-8 bg-gray-300 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {lowStockProducts?.slice(0, 6).map((product) => (
                  <div key={product.id} className="p-4 border border-red-200 bg-red-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-900">{product.name}</span>
                      <Badge variant="destructive" className="text-xs">
                        {product.stock} adet
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mb-3">
                      Minimum: {product.minStock} adet
                    </p>
                    <Button
                      size="sm"
                      className="w-full bg-red-600 hover:bg-red-700"
                      onClick={() => setLocation("/products")}
                    >
                      Stok Güncelle
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
