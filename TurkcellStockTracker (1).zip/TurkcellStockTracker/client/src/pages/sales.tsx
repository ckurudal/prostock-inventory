import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  Calculator, 
  Receipt,
  Search,
  Barcode,
  History
} from "lucide-react";
import type { ProductWithCategory, SaleWithItems } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import Cart from "@/components/pos/cart";
import BarcodeScanner from "@/components/barcode/scanner";

interface CartItem extends ProductWithCategory {
  quantity: number;
  subtotal: number;
}

export default function Sales() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [showSalesHistory, setShowSalesHistory] = useState(false);
  const { toast } = useToast();

  const { data: products = [] } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products"],
  });

  const { data: sales = [] } = useQuery<SaleWithItems[]>({
    queryKey: ["/api/sales"],
  });

  const createSaleMutation = useMutation({
    mutationFn: async (saleData: { sale: any; items: any[] }) => {
      const response = await fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(saleData),
      });
      if (!response.ok) throw new Error("Failed to create sale");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setCart([]);
      toast({
        title: "Başarılı",
        description: "Satış başarıyla tamamlandı",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Satış işlemi sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.barcode.includes(searchTerm)
  );

  const addToCart = (product: ProductWithCategory) => {
    if (product.stock <= 0) {
      toast({
        title: "Stok Yetersiz",
        description: "Bu ürün stokta bulunmuyor",
        variant: "destructive",
      });
      return;
    }

    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      if (existingItem.quantity >= product.stock) {
        toast({
          title: "Stok Yetersiz",
          description: "Stokta yeterli ürün bulunmuyor",
          variant: "destructive",
        });
        return;
      }
      updateQuantity(product.id, existingItem.quantity + 1);
    } else {
      const cartItem: CartItem = {
        ...product,
        quantity: 1,
        subtotal: parseFloat(product.sellPrice),
      };
      setCart([...cart, cartItem]);
    }
  };

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCart(cart.map(item => {
      if (item.id === productId) {
        const product = products.find(p => p.id === productId);
        if (product && newQuantity > product.stock) {
          toast({
            title: "Stok Yetersiz",
            description: "Stokta yeterli ürün bulunmuyor",
            variant: "destructive",
          });
          return item;
        }
        return {
          ...item,
          quantity: newQuantity,
          subtotal: parseFloat(item.sellPrice) * newQuantity,
        };
      }
      return item;
    }));
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.subtotal, 0);
  };

  const calculateTax = (subtotal: number) => {
    return subtotal * 0.20; // %20 KDV
  };

  const handleBarcodeScanned = (barcode: string) => {
    const product = products.find(p => p.barcode === barcode);
    if (product) {
      addToCart(product);
      toast({
        title: "Ürün Eklendi",
        description: `${product.name} sepete eklendi`,
      });
    } else {
      toast({
        title: "Ürün Bulunamadı",
        description: "Bu barkoda ait ürün bulunamadı",
        variant: "destructive",
      });
    }
    setIsScannerOpen(false);
  };

  const completeSale = () => {
    if (cart.length === 0) {
      toast({
        title: "Sepet Boş",
        description: "Lütfen sepete ürün ekleyin",
        variant: "destructive",
      });
      return;
    }

    const subtotal = calculateTotal();
    const taxAmount = calculateTax(subtotal);
    const totalAmount = subtotal + taxAmount;

    const saleData = {
      sale: {
        totalAmount: totalAmount.toString(),
        taxAmount: taxAmount.toString(),
        paymentMethod,
        userId: 1, // Current user ID
      },
      items: cart.map(item => ({
        productId: item.id,
        quantity: item.quantity,
        unitPrice: item.sellPrice,
        totalPrice: item.subtotal.toString(),
      })),
    };

    createSaleMutation.mutate(saleData);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
    }).format(amount);
  };

  const subtotal = calculateTotal();
  const taxAmount = calculateTax(subtotal);
  const total = subtotal + taxAmount;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Product Selection */}
      <div className="lg:col-span-2 space-y-6">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Satış Ekranı</h2>
          <p className="text-gray-600">Ürün seçin ve satış işlemini tamamlayın</p>
        </div>

        {/* Search and Actions */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Ürün adı veya barkod ile arama yapın..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => setIsScannerOpen(true)}
              >
                <Barcode className="h-4 w-4 mr-2" />
                Barkod Oku
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowSalesHistory(true)}
              >
                <History className="h-4 w-4 mr-2" />
                Geçmiş
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Products Grid */}
        <Card>
          <CardHeader>
            <CardTitle>Ürünler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-h-96 overflow-y-auto custom-scrollbar">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    product.stock <= 0 
                      ? 'bg-gray-100 cursor-not-allowed opacity-50' 
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => addToCart(product)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900 text-sm truncate">
                      {product.name}
                    </h4>
                    <Badge 
                      variant={product.stock <= 0 ? "destructive" : product.stock <= product.minStock ? "secondary" : "default"}
                      className="text-xs"
                    >
                      {product.stock}
                    </Badge>
                  </div>
                  <p className="text-lg font-bold text-green-600 mb-1">
                    {formatCurrency(parseFloat(product.sellPrice))}
                  </p>
                  <p className="text-xs text-gray-500 font-mono">{product.barcode}</p>
                  <p className="text-xs text-gray-500">{product.category?.name}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Cart and Checkout */}
      <div className="space-y-6">
        <Cart
          items={cart}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeFromCart}
          onClearCart={clearCart}
        />

        {/* Payment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calculator className="h-5 w-5" />
              <span>Ödeme</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Ödeme Yöntemi</label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Nakit</SelectItem>
                  <SelectItem value="card">Kredi Kartı</SelectItem>
                  <SelectItem value="transfer">Havale/EFT</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Ara Toplam:</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>KDV (%20):</span>
                <span>{formatCurrency(taxAmount)}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>Toplam:</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>

            <Button
              size="lg"
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={completeSale}
              disabled={cart.length === 0 || createSaleMutation.isPending}
            >
              <Receipt className="h-5 w-5 mr-2" />
              {createSaleMutation.isPending ? "İşleniyor..." : "Satışı Tamamla"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Barcode Scanner Modal */}
      <Dialog open={isScannerOpen} onOpenChange={setIsScannerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Barkod Okut</DialogTitle>
          </DialogHeader>
          <BarcodeScanner
            onScan={handleBarcodeScanned}
            onClose={() => setIsScannerOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Sales History Modal */}
      <Dialog open={showSalesHistory} onOpenChange={setShowSalesHistory}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Satış Geçmişi</DialogTitle>
          </DialogHeader>
          <div className="max-h-96 overflow-y-auto">
            <div className="space-y-4">
              {sales.slice(0, 10).map((sale) => (
                <div key={sale.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Satış #{sale.id}</span>
                    <span className="text-sm text-gray-500">
                      {new Date(sale.createdAt!).toLocaleString('tr-TR')}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    {sale.items.length} ürün • {sale.paymentMethod}
                  </div>
                  <div className="font-bold text-green-600">
                    {formatCurrency(parseFloat(sale.totalAmount))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
