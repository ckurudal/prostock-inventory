import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Camera, Search, Package, ShoppingCart, Printer } from "lucide-react";
import type { ProductWithCategory } from "@shared/schema";
import BarcodeScanner from "@/components/barcode/scanner";
import BarcodeGenerator from "@/components/barcode/generator";

export default function Barcode() {
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [manualBarcode, setManualBarcode] = useState("");
  const [scannedProduct, setScannedProduct] = useState<ProductWithCategory | null>(null);
  const { toast } = useToast();

  const { data: products = [] } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products"],
  });

  const handleBarcodeScanned = async (barcode: string) => {
    try {
      const response = await fetch(`/api/products/barcode/${barcode}`, {
        credentials: "include",
      });
      
      if (response.ok) {
        const product = await response.json();
        setScannedProduct(product);
        toast({
          title: "Ürün Bulundu",
          description: `${product.name} - Stok: ${product.stock}`,
        });
      } else {
        toast({
          title: "Ürün Bulunamadı",
          description: "Bu barkoda ait ürün bulunamadı",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Hata",
        description: "Barkod sorgulanırken bir hata oluştu",
        variant: "destructive",
      });
    }
    setIsScannerOpen(false);
  };

  const handleManualSearch = () => {
    if (!manualBarcode.trim()) return;
    handleBarcodeScanned(manualBarcode);
  };

  const handleQuickSale = () => {
    if (!scannedProduct) return;
    
    toast({
      title: "Satış İşlemi",
      description: "Satış ekranına yönlendiriliyorsunuz...",
    });
    
    // In a real app, you would navigate to sales page with the product
    window.location.href = `/sales?product=${scannedProduct.id}`;
  };

  const getStockStatus = (product: ProductWithCategory) => {
    if (product.stock <= 0) return { label: "Stokta Yok", variant: "destructive" as const };
    if (product.stock <= product.minStock) return { label: "Düşük Stok", variant: "secondary" as const };
    return { label: "Stokta Var", variant: "default" as const };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Barkod Sistemi</h2>
        <p className="text-gray-600">Barkod okutun veya oluşturun</p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <Button
              size="lg"
              className="w-full h-20 bg-primary hover:bg-primary/90"
              onClick={() => setIsScannerOpen(true)}
            >
              <div className="flex flex-col items-center space-y-2">
                <Camera className="h-8 w-8" />
                <span className="font-medium">Kamera ile Oku</span>
              </div>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <Button
              size="lg"
              variant="outline"
              className="w-full h-20"
              onClick={() => setIsGeneratorOpen(true)}
            >
              <div className="flex flex-col items-center space-y-2">
                <Printer className="h-8 w-8" />
                <span className="font-medium">Barkod Oluştur</span>
              </div>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="space-y-3">
              <Input
                placeholder="Barkod numarası girin"
                value={manualBarcode}
                onChange={(e) => setManualBarcode(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleManualSearch()}
              />
              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={handleManualSearch}
              >
                <Search className="h-4 w-4 mr-2" />
                Manuel Ara
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Scanned Product Details */}
      {scannedProduct && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Bulunan Ürün</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {scannedProduct.name}
                  </h3>
                  <p className="text-gray-600">{scannedProduct.description}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Barkod</label>
                    <p className="font-mono text-lg">{scannedProduct.barcode}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Kategori</label>
                    <p>{scannedProduct.category?.name || "-"}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Satış Fiyatı</label>
                    <p className="text-xl font-bold text-green-600">
                      ₺{scannedProduct.sellPrice}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Stok Durumu</label>
                    <div className="flex items-center space-x-2">
                      <Badge variant={getStockStatus(scannedProduct).variant}>
                        {getStockStatus(scannedProduct).label}
                      </Badge>
                      <span className="text-sm text-gray-600">
                        ({scannedProduct.stock} adet)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col space-y-3">
                <Button
                  size="lg"
                  className="bg-green-600 hover:bg-green-700"
                  onClick={handleQuickSale}
                  disabled={scannedProduct.stock <= 0}
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Hızlı Satış
                </Button>
                
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setIsGeneratorOpen(true)}
                >
                  <Printer className="h-5 w-5 mr-2" />
                  Barkod Etiket Yazdır
                </Button>
                
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setScannedProduct(null)}
                >
                  Temizle
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Products */}
      <Card>
        <CardHeader>
          <CardTitle>Son Eklenen Ürünler</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.slice(0, 6).map((product) => (
              <div
                key={product.id}
                className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                onClick={() => setScannedProduct(product)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900 truncate">
                    {product.name}
                  </h4>
                  <Badge variant={getStockStatus(product).variant} className="text-xs">
                    {product.stock}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 font-mono">{product.barcode}</p>
                <p className="text-sm text-gray-500">{product.category?.name}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Barcode Scanner Modal */}
      <Dialog open={isScannerOpen} onOpenChange={setIsScannerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Barkod Okut</DialogTitle>
          </DialogHeader>
          <BarcodeScanner
            onScan={handleBarcodeScanned}
            onClose={() => setIsScannerOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Barcode Generator Modal */}
      <Dialog open={isGeneratorOpen} onOpenChange={setIsGeneratorOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Barkod Oluştur</DialogTitle>
          </DialogHeader>
          <BarcodeGenerator
            products={products}
            selectedProduct={scannedProduct}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
