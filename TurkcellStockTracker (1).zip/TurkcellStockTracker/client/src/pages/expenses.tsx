import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Calendar, DollarSign, AlertTriangle, Clock, CheckCircle2, XCircle } from "lucide-react";
import { formatCurrency } from "@/lib/currency";
import { apiRequest } from "@/lib/queryClient";
import type { ExpenseWithCategory, ExpenseCategory, UpcomingExpense } from "@shared/schema";

export default function Expenses() {
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<ExpenseWithCategory | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: expenses = [], isLoading } = useQuery<ExpenseWithCategory[]>({
    queryKey: ['/api/expenses'],
  });

  const { data: categories = [] } = useQuery<ExpenseCategory[]>({
    queryKey: ['/api/expense-categories'],
  });

  const { data: upcomingExpenses = [] } = useQuery<UpcomingExpense[]>({
    queryKey: ['/api/expenses/upcoming'],
  });

  const markAsPaidMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('PATCH', `/api/expenses/${id}/pay`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/upcoming'] });
      toast({
        title: "Başarılı",
        description: "Gider ödendi olarak işaretlendi",
      });
    },
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/expenses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      toast({
        title: "Başarılı",
        description: "Gider silindi",
      });
    },
  });

  const filteredExpenses = expenses.filter(expense => {
    const matchesStatus = filterStatus === "all" || 
                         (filterStatus === "paid" && expense.isPaid) ||
                         (filterStatus === "unpaid" && !expense.isPaid) ||
                         (filterStatus === "overdue" && !expense.isPaid && new Date(expense.dueDate) < new Date());
    
    const matchesCategory = filterCategory === "all" || 
                           expense.categoryId.toString() === filterCategory;
    
    return matchesStatus && matchesCategory;
  });

  const getStatusBadge = (expense: ExpenseWithCategory) => {
    if (expense.isPaid) {
      return <Badge className="bg-green-100 text-green-800">Ödendi</Badge>;
    }
    
    const dueDate = new Date(expense.dueDate);
    const today = new Date();
    
    if (dueDate < today) {
      return <Badge className="bg-red-100 text-red-800">Gecikmiş</Badge>;
    }
    
    const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilDue <= 7) {
      return <Badge className="bg-orange-100 text-orange-800">Yaklaşan</Badge>;
    }
    
    return <Badge className="bg-blue-100 text-blue-800">Beklemede</Badge>;
  };

  const totalMonthlyExpenses = expenses
    .filter(expense => {
      const expenseDate = new Date(expense.dueDate);
      const currentMonth = new Date();
      return expenseDate.getMonth() === currentMonth.getMonth() && 
             expenseDate.getFullYear() === currentMonth.getFullYear();
    })
    .reduce((sum, expense) => sum + parseFloat(expense.amount), 0);

  const unpaidExpenses = expenses.filter(expense => !expense.isPaid);
  const overdueExpenses = expenses.filter(expense => 
    !expense.isPaid && new Date(expense.dueDate) < new Date()
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Gider Yönetimi</h1>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button className="turkcell-gradient text-white">
              <Plus className="mr-2 h-4 w-4" />
              Yeni Gider
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingExpense ? "Gider Düzenle" : "Yeni Gider Ekle"}
              </DialogTitle>
            </DialogHeader>
            {/* ExpenseForm component buraya gelecek */}
            <div className="p-4 text-center text-gray-500">
              Gider formu bileşeni yükleniyor...
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* İstatistik Kartları */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aylık Giderler</CardTitle>
            <DollarSign className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(totalMonthlyExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">Bu ay toplam</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ödenmemiş</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {unpaidExpenses.length}
            </div>
            <p className="text-xs text-muted-foreground">Bekleyen ödeme</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gecikmiş</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {overdueExpenses.length}
            </div>
            <p className="text-xs text-muted-foreground">Vadesi geçmiş</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Yaklaşan Ödemeler</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {upcomingExpenses.length}
            </div>
            <p className="text-xs text-muted-foreground">7 gün içinde</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtreler */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger>
            <SelectValue placeholder="Durum filtresi" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tümü</SelectItem>
            <SelectItem value="paid">Ödendi</SelectItem>
            <SelectItem value="unpaid">Ödenmemiş</SelectItem>
            <SelectItem value="overdue">Gecikmiş</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Kategori filtresi" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tüm Kategoriler</SelectItem>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id.toString()}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="text-sm text-gray-500 flex items-center">
          <DollarSign className="mr-2 h-4 w-4" />
          {filteredExpenses.length} gider bulundu
        </div>
      </div>

      {/* Yaklaşan Ödemeler */}
      {upcomingExpenses.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5 text-orange-500" />
              Yaklaşan Ödemeler (7 Gün İçinde)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingExpenses.map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 border rounded bg-orange-50 dark:bg-orange-900/20">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: expense.categoryColor || '#6B7280' }}
                    />
                    <div>
                      <p className="font-medium">{expense.title}</p>
                      <p className="text-sm text-gray-500">{expense.categoryName}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(expense.amount)}</p>
                    <p className="text-sm text-orange-600">
                      {expense.daysUntilDue} gün kaldı
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Gider Listesi */}
      <div className="grid grid-cols-1 gap-4">
        {filteredExpenses.map((expense) => (
          <Card key={expense.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: expense.category.color || '#6B7280' }}
                  />
                  <div>
                    <h3 className="font-medium">{expense.title}</h3>
                    <p className="text-sm text-gray-500">{expense.category.name}</p>
                    {expense.notes && (
                      <p className="text-sm text-gray-400 mt-1">{expense.notes}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="font-bold text-lg">{formatCurrency(parseFloat(expense.amount))}</p>
                    <p className="text-sm text-gray-500">
                      Vade: {new Date(expense.dueDate).toLocaleDateString('tr-TR')}
                    </p>
                    {expense.paymentDate && (
                      <p className="text-sm text-green-600">
                        Ödendi: {new Date(expense.paymentDate).toLocaleDateString('tr-TR')}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col items-end space-y-2">
                    {getStatusBadge(expense)}
                    
                    <div className="flex space-x-2">
                      {!expense.isPaid && (
                        <Button
                          size="sm"
                          onClick={() => markAsPaidMutation.mutate(expense.id)}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          <CheckCircle2 className="h-3 w-3" />
                        </Button>
                      )}
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingExpense(expense);
                          setIsFormOpen(true);
                        }}
                      >
                        Düzenle
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          if (confirm(`"${expense.title}" giderini silmek istediğinizden emin misiniz?`)) {
                            deleteExpenseMutation.mutate(expense.id);
                          }
                        }}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <XCircle className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredExpenses.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <DollarSign className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Gider bulunamadı
            </h3>
            <p className="text-gray-500 mb-4">
              Henüz gider eklenmemiş veya filtrelere uygun gider yok.
            </p>
            <Button onClick={() => setIsFormOpen(true)}>
              İlk Gideri Ekle
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Gider Formu */}
      <ExpenseForm
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingExpense(null);
        }}
        expense={editingExpense}
        categories={categories}
      />

      {/* Kategori Yönetimi */}
      <CategoryManagement categories={categories} />
    </div>
  );
}

// ExpenseForm bileşeni
function ExpenseForm({ 
  isOpen, 
  onClose, 
  expense, 
  categories 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  expense?: ExpenseWithCategory | null;
  categories: ExpenseCategory[];
}) {
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    categoryId: '',
    dueDate: '',
    notes: '',
    isRecurring: false,
    recurringType: 'monthly'
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createExpenseMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/expenses', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/upcoming'] });
      toast({
        title: "Başarılı",
        description: "Gider başarıyla eklendi",
      });
      onClose();
      setFormData({
        title: '',
        amount: '',
        categoryId: '',
        dueDate: '',
        notes: '',
        isRecurring: false,
        recurringType: 'monthly'
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Gider eklenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const updateExpenseMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('PUT', `/api/expenses/${expense?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/upcoming'] });
      toast({
        title: "Başarılı",
        description: "Gider başarıyla güncellendi",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Gider güncellenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.amount || !formData.categoryId || !formData.dueDate) {
      toast({
        title: "Hata",
        description: "Lütfen tüm zorunlu alanları doldurun",
        variant: "destructive",
      });
      return;
    }

    const data = {
      ...formData,
      categoryId: parseInt(formData.categoryId),
      amount: formData.amount,
    };

    if (expense) {
      updateExpenseMutation.mutate(data);
    } else {
      createExpenseMutation.mutate(data);
    }
  };

  // Form verilerini expense ile doldur
  useEffect(() => {
    if (expense && isOpen) {
      setFormData({
        title: expense.title,
        amount: expense.amount,
        categoryId: expense.categoryId.toString(),
        dueDate: new Date(expense.dueDate).toISOString().split('T')[0],
        notes: expense.notes || '',
        isRecurring: expense.isRecurring || false,
        recurringType: expense.recurringType || 'monthly'
      });
    }
  }, [expense, isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {expense ? 'Gider Düzenle' : 'Yeni Gider Ekle'}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Gider Başlığı *</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Örn: Elektrik Faturası"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Tutar (₺) *</label>
            <Input
              type="number"
              step="0.01"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="0.00"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Kategori *</label>
            <Select value={formData.categoryId} onValueChange={(value) => setFormData({ ...formData, categoryId: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Kategori seçin" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Vade Tarihi *</label>
            <Input
              type="date"
              value={formData.dueDate}
              onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Notlar</label>
            <Input
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Opsiyonel notlar..."
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="isRecurring"
              checked={formData.isRecurring}
              onChange={(e) => setFormData({ ...formData, isRecurring: e.target.checked })}
              className="rounded"
            />
            <label htmlFor="isRecurring" className="text-sm">Düzenli gider</label>
          </div>

          {formData.isRecurring && (
            <div>
              <label className="block text-sm font-medium mb-2">Tekrarlama Türü</label>
              <Select value={formData.recurringType} onValueChange={(value) => setFormData({ ...formData, recurringType: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Haftalık</SelectItem>
                  <SelectItem value="monthly">Aylık</SelectItem>
                  <SelectItem value="yearly">Yıllık</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              İptal
            </Button>
            <Button 
              type="submit" 
              disabled={createExpenseMutation.isPending || updateExpenseMutation.isPending}
            >
              {createExpenseMutation.isPending || updateExpenseMutation.isPending ? 'Kaydediliyor...' : expense ? 'Güncelle' : 'Ekle'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Kategori Yönetimi bileşeni
function CategoryManagement({ categories }: { categories: ExpenseCategory[] }) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<ExpenseCategory | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: '#3B82F6'
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createCategoryMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/expense-categories', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expense-categories'] });
      toast({
        title: "Başarılı",
        description: "Kategori başarıyla eklendi",
      });
      setIsOpen(false);
      setFormData({ name: '', description: '', color: '#3B82F6' });
    },
  });

  const updateCategoryMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('PUT', `/api/expense-categories/${editingCategory?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expense-categories'] });
      toast({
        title: "Başarılı",
        description: "Kategori başarıyla güncellendi",
      });
      setIsOpen(false);
      setEditingCategory(null);
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/expense-categories/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expense-categories'] });
      toast({
        title: "Başarılı",
        description: "Kategori başarıyla silindi",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name) {
      toast({
        title: "Hata",
        description: "Kategori adı zorunludur",
        variant: "destructive",
      });
      return;
    }

    if (editingCategory) {
      updateCategoryMutation.mutate(formData);
    } else {
      createCategoryMutation.mutate(formData);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="fixed bottom-20 right-4">
            Kategori Yönet
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Gider Kategorileri</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: category.color || '#6B7280' }}
                    />
                    <span>{category.name}</span>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingCategory(category);
                        setFormData({
                          name: category.name,
                          description: category.description || '',
                          color: category.color || '#3B82F6'
                        });
                      }}
                    >
                      Düzenle
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        if (confirm(`"${category.name}" kategorisini silmek istediğinizden emin misiniz?`)) {
                          deleteCategoryMutation.mutate(category.id);
                        }
                      }}
                      className="text-red-600"
                    >
                      Sil
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 border-t pt-4">
              <h4 className="font-medium">
                {editingCategory ? 'Kategori Düzenle' : 'Yeni Kategori Ekle'}
              </h4>
              
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Kategori adı"
                required
              />
              
              <Input
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Açıklama (opsiyonel)"
              />
              
              <div className="flex items-center space-x-2">
                <label className="text-sm">Renk:</label>
                <input
                  type="color"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="w-8 h-8 rounded border"
                />
              </div>
              
              <div className="flex space-x-2">
                <Button type="submit" disabled={createCategoryMutation.isPending || updateCategoryMutation.isPending}>
                  {editingCategory ? 'Güncelle' : 'Ekle'}
                </Button>
                {editingCategory && (
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setEditingCategory(null);
                      setFormData({ name: '', description: '', color: '#3B82F6' });
                    }}
                  >
                    İptal
                  </Button>
                )}
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}