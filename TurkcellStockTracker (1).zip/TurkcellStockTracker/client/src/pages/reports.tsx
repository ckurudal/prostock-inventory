import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { 
  BarChart3, 
  Download, 
  FileText, 
  Calendar as CalendarIcon,
  TrendingUp,
  Package,
  DollarSign
} from "lucide-react";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import type { SaleWithItems, DashboardStats } from "@shared/schema";
import { exportToExcel, exportToPDF } from "@/lib/export";
import ReportChart from "@/components/reports/chart";

export default function Reports() {
  const [dateRange, setDateRange] = useState({
    from: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    to: new Date(),
  });
  const [reportType, setReportType] = useState("daily");
  const { toast } = useToast();

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: sales = [] } = useQuery<SaleWithItems[]>({
    queryKey: ["/api/sales"],
  });

  const { data: salesInRange = [] } = useQuery<SaleWithItems[]>({
    queryKey: [
      "/api/sales/date-range",
      format(dateRange.from, "yyyy-MM-dd"),
      format(dateRange.to, "yyyy-MM-dd"),
    ],
  });

  const generateSalesReport = () => {
    const reportData = salesInRange.map(sale => ({
      "Satış No": sale.id,
      "Tarih": format(new Date(sale.createdAt!), "dd/MM/yyyy HH:mm", { locale: tr }),
      "Toplam Tutar": `₺${sale.totalAmount}`,
      "KDV": `₺${sale.taxAmount}`,
      "Ödeme Yöntemi": sale.paymentMethod === "cash" ? "Nakit" : sale.paymentMethod === "card" ? "Kart" : "Transfer",
      "Ürün Sayısı": sale.items.length,
      "Satıcı": sale.user?.name || "Bilinmiyor",
    }));

    exportToExcel(reportData, `satis-raporu-${format(new Date(), "yyyy-MM-dd")}`);
    toast({
      title: "Başarılı",
      description: "Satış raporu Excel olarak dışa aktarıldı",
    });
  };

  const generateProductReport = () => {
    // Group sales by product
    const productSales: Record<string, { name: string; quantity: number; revenue: number; count: number }> = {};
    
    salesInRange.forEach(sale => {
      sale.items.forEach(item => {
        const key = item.product.name;
        if (!productSales[key]) {
          productSales[key] = {
            name: item.product.name,
            quantity: 0,
            revenue: 0,
            count: 0,
          };
        }
        productSales[key].quantity += item.quantity;
        productSales[key].revenue += parseFloat(item.totalPrice);
        productSales[key].count += 1;
      });
    });

    const reportData = Object.values(productSales)
      .sort((a, b) => b.revenue - a.revenue)
      .map(product => ({
        "Ürün Adı": product.name,
        "Satış Adedi": product.quantity,
        "Satış Sayısı": product.count,
        "Toplam Gelir": `₺${product.revenue.toFixed(2)}`,
        "Ortalama Satış": `₺${(product.revenue / product.count).toFixed(2)}`,
      }));

    exportToExcel(reportData, `urun-raporu-${format(new Date(), "yyyy-MM-dd")}`);
    toast({
      title: "Başarılı",
      description: "Ürün raporu Excel olarak dışa aktarıldı",
    });
  };

  const generatePDFReport = () => {
    const reportData = {
      title: "Satış Raporu",
      period: `${format(dateRange.from, "dd/MM/yyyy", { locale: tr })} - ${format(dateRange.to, "dd/MM/yyyy", { locale: tr })}`,
      summary: {
        totalSales: salesInRange.length,
        totalRevenue: salesInRange.reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0),
        averageSale: salesInRange.length > 0 ? salesInRange.reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0) / salesInRange.length : 0,
      },
      details: salesInRange.slice(0, 10).map(sale => ({
        id: sale.id,
        date: format(new Date(sale.createdAt!), "dd/MM/yyyy HH:mm", { locale: tr }),
        amount: parseFloat(sale.totalAmount),
        items: sale.items.length,
      })),
    };

    exportToPDF(reportData);
    toast({
      title: "Başarılı",
      description: "Rapor PDF olarak dışa aktarıldı",
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency: 'TRY',
    }).format(amount);
  };

  const totalRevenue = salesInRange.reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);
  const totalTax = salesInRange.reduce((sum, sale) => sum + parseFloat(sale.taxAmount), 0);
  const averageSale = salesInRange.length > 0 ? totalRevenue / salesInRange.length : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Raporlar</h2>
          <p className="text-gray-600">Satış ve ürün analizleri</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={generatePDFReport}>
            <FileText className="h-4 w-4 mr-2" />
            PDF İndir
          </Button>
          <Button variant="outline" onClick={generateSalesReport}>
            <Download className="h-4 w-4 mr-2" />
            Excel İndir
          </Button>
        </div>
      </div>

      {/* Date Range Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4 items-end">
            <div className="space-y-2">
              <Label>Başlangıç Tarihi</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(dateRange.from, "dd/MM/yyyy", { locale: tr })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(date) => date && setDateRange({ ...dateRange, from: date })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label>Bitiş Tarihi</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(dateRange.to, "dd/MM/yyyy", { locale: tr })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.to}
                    onSelect={(date) => date && setDateRange({ ...dateRange, to: date })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Rapor Türü</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Günlük</SelectItem>
                  <SelectItem value="weekly">Haftalık</SelectItem>
                  <SelectItem value="monthly">Aylık</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Toplam Satış</p>
                <p className="text-2xl font-bold text-gray-900">{salesInRange.length}</p>
                <p className="text-xs text-blue-600 mt-1">
                  Seçilen dönem
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Toplam Gelir</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRevenue)}</p>
                <p className="text-xs text-green-600 mt-1">
                  KDV dahil
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ortalama Satış</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(averageSale)}</p>
                <p className="text-xs text-purple-600 mt-1">
                  Per satış
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Toplam KDV</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalTax)}</p>
                <p className="text-xs text-orange-600 mt-1">
                  %20 oran
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Package className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reports Tabs */}
      <Tabs defaultValue="sales" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sales">Satış Analizi</TabsTrigger>
          <TabsTrigger value="products">Ürün Analizi</TabsTrigger>
          <TabsTrigger value="chart">Grafik Görünüm</TabsTrigger>
        </TabsList>

        <TabsContent value="sales" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Satış Detayları</CardTitle>
              <Button variant="outline" onClick={generateSalesReport}>
                <Download className="h-4 w-4 mr-2" />
                Excel'e Aktar
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Satış No</th>
                      <th className="text-left p-2">Tarih</th>
                      <th className="text-left p-2">Ürün Sayısı</th>
                      <th className="text-left p-2">Tutar</th>
                      <th className="text-left p-2">Ödeme</th>
                    </tr>
                  </thead>
                  <tbody>
                    {salesInRange.slice(0, 10).map((sale) => (
                      <tr key={sale.id} className="border-b">
                        <td className="p-2">#{sale.id}</td>
                        <td className="p-2">
                          {format(new Date(sale.createdAt!), "dd/MM/yyyy HH:mm", { locale: tr })}
                        </td>
                        <td className="p-2">{sale.items.length}</td>
                        <td className="p-2 font-medium">{formatCurrency(parseFloat(sale.totalAmount))}</td>
                        <td className="p-2">
                          <span className="px-2 py-1 bg-gray-100 rounded text-xs">
                            {sale.paymentMethod === "cash" ? "Nakit" : sale.paymentMethod === "card" ? "Kart" : "Transfer"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>En Çok Satan Ürünler</CardTitle>
              <Button variant="outline" onClick={generateProductReport}>
                <Download className="h-4 w-4 mr-2" />
                Excel'e Aktar
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(() => {
                  const productSales: Record<string, { name: string; quantity: number; revenue: number }> = {};
                  
                  salesInRange.forEach(sale => {
                    sale.items.forEach(item => {
                      const key = item.product.name;
                      if (!productSales[key]) {
                        productSales[key] = {
                          name: item.product.name,
                          quantity: 0,
                          revenue: 0,
                        };
                      }
                      productSales[key].quantity += item.quantity;
                      productSales[key].revenue += parseFloat(item.totalPrice);
                    });
                  });

                  return Object.values(productSales)
                    .sort((a, b) => b.quantity - a.quantity)
                    .slice(0, 10)
                    .map((product, index) => (
                      <div key={product.name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white text-sm font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{product.name}</p>
                            <p className="text-sm text-gray-500">{product.quantity} adet satıldı</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">{formatCurrency(product.revenue)}</p>
                          <p className="text-sm text-gray-500">Toplam gelir</p>
                        </div>
                      </div>
                    ));
                })()}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chart" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Satış Grafiği</CardTitle>
            </CardHeader>
            <CardContent>
              <ReportChart sales={salesInRange} type={reportType} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
