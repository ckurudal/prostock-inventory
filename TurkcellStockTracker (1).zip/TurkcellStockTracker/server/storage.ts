import { neon } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-http';
import { eq, and, gte, lte, desc, asc } from 'drizzle-orm';
import {
  users, categories, products, sales, saleItems, settings,
  expenseCategories, expenses,
  type User, type InsertUser,
  type Category, type InsertCategory,
  type Product, type InsertProduct, type ProductWithCategory,
  type Sale, type InsertSale, type SaleWithItems,
  type SaleItem, type InsertSaleItem,
  type Setting, type InsertSetting,
  type ExpenseCategory, type InsertExpenseCategory,
  type Expense, type InsertExpense, type ExpenseWithCategory,
  type DashboardStats, type RecentSale,
  type UpcomingExpense, type ExpenseStats
} from "@shared/schema";

const sql = neon(process.env.DATABASE_URL!);
const db = drizzle(sql);

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(username: string, password: string): Promise<User | null>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Products
  getProducts(): Promise<ProductWithCategory[]>;
  getProduct(id: number): Promise<ProductWithCategory | undefined>;
  getProductByBarcode(barcode: string): Promise<ProductWithCategory | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  updateStock(productId: number, quantity: number): Promise<boolean>;

  // Sales
  getSales(): Promise<SaleWithItems[]>;
  getSale(id: number): Promise<SaleWithItems | undefined>;
  createSale(sale: InsertSale, items: InsertSaleItem[]): Promise<Sale>;
  getSalesByDateRange(startDate: Date, endDate: Date): Promise<SaleWithItems[]>;

  // Settings
  getSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<Setting | undefined>;
  setSetting(setting: InsertSetting): Promise<Setting>;

  // Expense Categories
  getExpenseCategories(): Promise<ExpenseCategory[]>;
  getExpenseCategory(id: number): Promise<ExpenseCategory | undefined>;
  createExpenseCategory(category: InsertExpenseCategory): Promise<ExpenseCategory>;
  updateExpenseCategory(id: number, category: Partial<InsertExpenseCategory>): Promise<ExpenseCategory | undefined>;
  deleteExpenseCategory(id: number): Promise<boolean>;

  // Expenses
  getExpenses(): Promise<ExpenseWithCategory[]>;
  getExpense(id: number): Promise<ExpenseWithCategory | undefined>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
  markExpenseAsPaid(id: number): Promise<boolean>;
  getUpcomingExpenses(days?: number): Promise<UpcomingExpense[]>;
  getExpenseStats(): Promise<ExpenseStats>;

  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;
  getRecentSales(limit?: number): Promise<RecentSale[]>;
  getLowStockProducts(): Promise<ProductWithCategory[]>;
}

export class DbStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async validateUser(username: string, password: string): Promise<User | null> {
    const result = await db.select().from(users)
      .where(and(eq(users.username, username), eq(users.password, password)))
      .limit(1);
    return result[0] || null;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.name));
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
    return result[0];
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(insertCategory).returning();
    return result[0];
  }

  async updateCategory(id: number, insertCategory: Partial<InsertCategory>): Promise<Category | undefined> {
    const result = await db.update(categories)
      .set(insertCategory)
      .where(eq(categories.id, id))
      .returning();
    return result[0];
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id)).returning();
    return result.length > 0;
  }

  // Products
  async getProducts(): Promise<ProductWithCategory[]> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      barcode: products.barcode,
      description: products.description,
      categoryId: products.categoryId,
      buyPrice: products.buyPrice,
      sellPrice: products.sellPrice,
      stock: products.stock,
      minStock: products.minStock,
      isActive: products.isActive,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        description: categories.description,
      }
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .orderBy(asc(products.name));

    return result.map(row => ({
      ...row,
      category: row.category.id ? row.category : undefined
    }));
  }

  async getProduct(id: number): Promise<ProductWithCategory | undefined> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      barcode: products.barcode,
      description: products.description,
      categoryId: products.categoryId,
      buyPrice: products.buyPrice,
      sellPrice: products.sellPrice,
      stock: products.stock,
      minStock: products.minStock,
      isActive: products.isActive,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        description: categories.description,
      }
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.id, id))
    .limit(1);

    if (!result[0]) return undefined;
    
    const row = result[0];
    return {
      ...row,
      category: row.category.id ? row.category : undefined
    };
  }

  async getProductByBarcode(barcode: string): Promise<ProductWithCategory | undefined> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      barcode: products.barcode,
      description: products.description,
      categoryId: products.categoryId,
      buyPrice: products.buyPrice,
      sellPrice: products.sellPrice,
      stock: products.stock,
      minStock: products.minStock,
      isActive: products.isActive,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        description: categories.description,
      }
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.barcode, barcode))
    .limit(1);

    if (!result[0]) return undefined;
    
    const row = result[0];
    return {
      ...row,
      category: row.category.id ? row.category : undefined
    };
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(insertProduct).returning();
    return result[0];
  }

  async updateProduct(id: number, insertProduct: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db.update(products)
      .set(insertProduct)
      .where(eq(products.id, id))
      .returning();
    return result[0];
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning();
    return result.length > 0;
  }

  async updateStock(productId: number, quantity: number): Promise<boolean> {
    const result = await db.update(products)
      .set({ stock: quantity })
      .where(eq(products.id, productId))
      .returning();
    return result.length > 0;
  }

  // Sales
  async getSales(): Promise<SaleWithItems[]> {
    const salesData = await db.select().from(sales).orderBy(desc(sales.createdAt));
    
    const enrichedSales: SaleWithItems[] = [];
    for (const sale of salesData) {
      const saleItemsData = await db.select({
        id: saleItems.id,
        saleId: saleItems.saleId,
        productId: saleItems.productId,
        quantity: saleItems.quantity,
        unitPrice: saleItems.unitPrice,
        totalPrice: saleItems.totalPrice,
        product: {
          id: products.id,
          name: products.name,
          barcode: products.barcode,
          description: products.description,
          categoryId: products.categoryId,
          buyPrice: products.buyPrice,
          sellPrice: products.sellPrice,
          stock: products.stock,
          minStock: products.minStock,
          isActive: products.isActive,
          createdAt: products.createdAt,
        }
      })
      .from(saleItems)
      .innerJoin(products, eq(saleItems.productId, products.id))
      .where(eq(saleItems.saleId, sale.id));

      enrichedSales.push({
        ...sale,
        items: saleItemsData
      });
    }
    
    return enrichedSales;
  }

  async getSale(id: number): Promise<SaleWithItems | undefined> {
    const saleData = await db.select().from(sales).where(eq(sales.id, id)).limit(1);
    if (!saleData[0]) return undefined;

    const sale = saleData[0];
    const saleItemsData = await db.select({
      id: saleItems.id,
      saleId: saleItems.saleId,
      productId: saleItems.productId,
      quantity: saleItems.quantity,
      unitPrice: saleItems.unitPrice,
      totalPrice: saleItems.totalPrice,
      product: {
        id: products.id,
        name: products.name,
        barcode: products.barcode,
        description: products.description,
        categoryId: products.categoryId,
        buyPrice: products.buyPrice,
        sellPrice: products.sellPrice,
        stock: products.stock,
        minStock: products.minStock,
        isActive: products.isActive,
        createdAt: products.createdAt,
      }
    })
    .from(saleItems)
    .innerJoin(products, eq(saleItems.productId, products.id))
    .where(eq(saleItems.saleId, sale.id));

    return {
      ...sale,
      items: saleItemsData
    };
  }

  async createSale(insertSale: InsertSale, items: InsertSaleItem[]): Promise<Sale> {
    const saleResult = await db.insert(sales).values(insertSale).returning();
    const sale = saleResult[0];

    // Insert sale items
    for (const item of items) {
      await db.insert(saleItems).values({
        ...item,
        saleId: sale.id
      });

      // Update product stock
      await db.update(products)
        .set({ stock: db.select({stock: products.stock}).from(products).where(eq(products.id, item.productId)) as any - item.quantity })
        .where(eq(products.id, item.productId));
    }

    return sale;
  }

  async getSalesByDateRange(startDate: Date, endDate: Date): Promise<SaleWithItems[]> {
    const salesData = await db.select().from(sales)
      .where(and(gte(sales.createdAt, startDate), lte(sales.createdAt, endDate)))
      .orderBy(desc(sales.createdAt));
    
    const enrichedSales: SaleWithItems[] = [];
    for (const sale of salesData) {
      const saleItemsData = await db.select({
        id: saleItems.id,
        saleId: saleItems.saleId,
        productId: saleItems.productId,
        quantity: saleItems.quantity,
        unitPrice: saleItems.unitPrice,
        totalPrice: saleItems.totalPrice,
        product: {
          id: products.id,
          name: products.name,
          barcode: products.barcode,
          description: products.description,
          categoryId: products.categoryId,
          buyPrice: products.buyPrice,
          sellPrice: products.sellPrice,
          stock: products.stock,
          minStock: products.minStock,
          isActive: products.isActive,
          createdAt: products.createdAt,
        }
      })
      .from(saleItems)
      .innerJoin(products, eq(saleItems.productId, products.id))
      .where(eq(saleItems.saleId, sale.id));

      enrichedSales.push({
        ...sale,
        items: saleItemsData
      });
    }
    
    return enrichedSales;
  }

  // Settings
  async getSettings(): Promise<Setting[]> {
    return await db.select().from(settings);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const result = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    return result[0];
  }

  async setSetting(insertSetting: InsertSetting): Promise<Setting> {
    // Upsert operation
    const existing = await this.getSetting(insertSetting.key);
    if (existing) {
      const result = await db.update(settings)
        .set(insertSetting)
        .where(eq(settings.key, insertSetting.key))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(settings).values(insertSetting).returning();
      return result[0];
    }
  }

  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    const productsData = await db.select().from(products);
    const salesData = await db.select().from(sales);
    
    const totalProducts = productsData.length;
    const stockValue = productsData.reduce((sum, p) => sum + (parseFloat(p.buyPrice) * p.stock), 0);
    const lowStockCount = productsData.filter(p => p.stock <= p.minStock).length;
    
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const dailySales = salesData.filter(s => s.createdAt && s.createdAt >= todayStart);
    const weeklySales = salesData.filter(s => s.createdAt && s.createdAt >= weekStart);
    const monthlySales = salesData.filter(s => s.createdAt && s.createdAt >= monthStart);
    
    const dailyRevenue = dailySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);
    const weeklyRevenue = weeklySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);
    const monthlyRevenue = monthlySales.reduce((sum, s) => sum + parseFloat(s.totalAmount), 0);
    
    return {
      totalProducts,
      stockValue,
      lowStockCount,
      dailyRevenue,
      weeklyRevenue,
      monthlyRevenue,
      totalSales: salesData.length
    };
  }

  async getRecentSales(limit = 10): Promise<RecentSale[]> {
    const recentSalesData = await db.select({
      id: sales.id,
      createdAt: sales.createdAt,
      totalAmount: sales.totalAmount,
      items: {
        quantity: saleItems.quantity,
        totalPrice: saleItems.totalPrice,
        product: {
          name: products.name,
          buyPrice: products.buyPrice
        }
      }
    })
    .from(sales)
    .innerJoin(saleItems, eq(sales.id, saleItems.saleId))
    .innerJoin(products, eq(saleItems.productId, products.id))
    .orderBy(desc(sales.createdAt))
    .limit(limit);

    return recentSalesData.map(sale => ({
      id: sale.id,
      productName: sale.items.product.name,
      quantity: sale.items.quantity,
      totalPrice: parseFloat(sale.items.totalPrice),
      profit: parseFloat(sale.items.totalPrice) - (parseFloat(sale.items.product.buyPrice) * sale.items.quantity),
      createdAt: sale.createdAt!
    }));
  }

  async getLowStockProducts(): Promise<ProductWithCategory[]> {
    const result = await db.select({
      id: products.id,
      name: products.name,
      barcode: products.barcode,
      description: products.description,
      categoryId: products.categoryId,
      buyPrice: products.buyPrice,
      sellPrice: products.sellPrice,
      stock: products.stock,
      minStock: products.minStock,
      isActive: products.isActive,
      createdAt: products.createdAt,
      category: {
        id: categories.id,
        name: categories.name,
        description: categories.description,
      }
    })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(lte(products.stock, products.minStock));

    return result.map(row => ({
      ...row,
      category: row.category.id ? row.category : undefined
    }));
  }

  // Expense Categories
  async getExpenseCategories(): Promise<ExpenseCategory[]> {
    return await db.select().from(expenseCategories);
  }

  async getExpenseCategory(id: number): Promise<ExpenseCategory | undefined> {
    const result = await db.select().from(expenseCategories).where(eq(expenseCategories.id, id)).limit(1);
    return result[0];
  }

  async createExpenseCategory(insertExpenseCategory: InsertExpenseCategory): Promise<ExpenseCategory> {
    const result = await db.insert(expenseCategories).values(insertExpenseCategory).returning();
    return result[0];
  }

  async updateExpenseCategory(id: number, insertExpenseCategory: Partial<InsertExpenseCategory>): Promise<ExpenseCategory | undefined> {
    const result = await db.update(expenseCategories).set(insertExpenseCategory).where(eq(expenseCategories.id, id)).returning();
    return result[0];
  }

  async deleteExpenseCategory(id: number): Promise<boolean> {
    const result = await db.delete(expenseCategories).where(eq(expenseCategories.id, id));
    return result.rowCount > 0;
  }

  // Expenses
  async getExpenses(): Promise<ExpenseWithCategory[]> {
    const result = await db.select({
      id: expenses.id,
      createdAt: expenses.createdAt,
      categoryId: expenses.categoryId,
      userId: expenses.userId,
      title: expenses.title,
      amount: expenses.amount,
      dueDate: expenses.dueDate,
      paymentDate: expenses.paymentDate,
      isPaid: expenses.isPaid,
      isRecurring: expenses.isRecurring,
      recurringType: expenses.recurringType,
      notes: expenses.notes,
      category: {
        id: expenseCategories.id,
        name: expenseCategories.name,
        description: expenseCategories.description,
        color: expenseCategories.color,
      }
    })
    .from(expenses)
    .leftJoin(expenseCategories, eq(expenses.categoryId, expenseCategories.id));

    return result.map(row => ({
      ...row,
      category: row.category.id ? row.category : { id: 0, name: 'Unknown', description: null, color: null }
    }));
  }

  async getExpense(id: number): Promise<ExpenseWithCategory | undefined> {
    const result = await db.select({
      id: expenses.id,
      createdAt: expenses.createdAt,
      categoryId: expenses.categoryId,
      userId: expenses.userId,
      title: expenses.title,
      amount: expenses.amount,
      dueDate: expenses.dueDate,
      paymentDate: expenses.paymentDate,
      isPaid: expenses.isPaid,
      isRecurring: expenses.isRecurring,
      recurringType: expenses.recurringType,
      notes: expenses.notes,
      category: {
        id: expenseCategories.id,
        name: expenseCategories.name,
        description: expenseCategories.description,
        color: expenseCategories.color,
      }
    })
    .from(expenses)
    .leftJoin(expenseCategories, eq(expenses.categoryId, expenseCategories.id))
    .where(eq(expenses.id, id))
    .limit(1);

    if (!result[0]) return undefined;

    return {
      ...result[0],
      category: result[0].category.id ? result[0].category : { id: 0, name: 'Unknown', description: null, color: null }
    };
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const result = await db.insert(expenses).values(insertExpense).returning();
    return result[0];
  }

  async updateExpense(id: number, insertExpense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const result = await db.update(expenses).set(insertExpense).where(eq(expenses.id, id)).returning();
    return result[0];
  }

  async deleteExpense(id: number): Promise<boolean> {
    const result = await db.delete(expenses).where(eq(expenses.id, id));
    return result.rowCount > 0;
  }

  async markExpenseAsPaid(id: number): Promise<boolean> {
    const result = await db.update(expenses)
      .set({ isPaid: true, paymentDate: new Date() })
      .where(eq(expenses.id, id));
    return result.rowCount > 0;
  }

  async getUpcomingExpenses(days = 7): Promise<UpcomingExpense[]> {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);

    const result = await db.select({
      id: expenses.id,
      title: expenses.title,
      amount: expenses.amount,
      dueDate: expenses.dueDate,
      categoryName: expenseCategories.name,
      categoryColor: expenseCategories.color,
    })
    .from(expenses)
    .leftJoin(expenseCategories, eq(expenses.categoryId, expenseCategories.id))
    .where(and(
      eq(expenses.isPaid, false),
      gte(expenses.dueDate, today),
      lte(expenses.dueDate, futureDate)
    ))
    .orderBy(asc(expenses.dueDate));

    return result.map(row => ({
      id: row.id,
      title: row.title,
      amount: parseFloat(row.amount),
      dueDate: row.dueDate,
      categoryName: row.categoryName || 'Unknown',
      categoryColor: row.categoryColor || '#6B7280',
      daysUntilDue: Math.ceil((row.dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    }));
  }

  async getExpenseStats(): Promise<ExpenseStats> {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    const monthStart = new Date(currentYear, currentMonth, 1);
    const monthEnd = new Date(currentYear, currentMonth + 1, 0);
    const yearStart = new Date(currentYear, 0, 1);
    const yearEnd = new Date(currentYear, 11, 31);

    const monthlyExpensesResult = await db.select({
      total: expenses.amount
    })
    .from(expenses)
    .where(and(
      gte(expenses.dueDate, monthStart),
      lte(expenses.dueDate, monthEnd)
    ));

    const yearlyExpensesResult = await db.select({
      total: expenses.amount
    })
    .from(expenses)
    .where(and(
      gte(expenses.dueDate, yearStart),
      lte(expenses.dueDate, yearEnd)
    ));

    const pendingResult = await db.select({ count: expenses.id })
      .from(expenses)
      .where(eq(expenses.isPaid, false));

    const overdueResult = await db.select({ count: expenses.id })
      .from(expenses)
      .where(and(
        eq(expenses.isPaid, false),
        lte(expenses.dueDate, today)
      ));

    const totalMonthlyExpenses = monthlyExpensesResult.reduce((sum, exp) => sum + parseFloat(exp.total), 0);
    const totalYearlyExpenses = yearlyExpensesResult.reduce((sum, exp) => sum + parseFloat(exp.total), 0);

    return {
      totalMonthlyExpenses,
      totalYearlyExpenses,
      pendingPayments: pendingResult.length,
      overduePayments: overdueResult.length,
    };
  }
}

// Keep MemStorage class for fallback
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private sales: Map<number, Sale>;
  private saleItems: Map<number, SaleItem>;
  private settings: Map<string, Setting>;
  private expenseCategories: Map<number, ExpenseCategory>;
  private expenses: Map<number, Expense>;
  private currentUserId: number;
  private currentCategoryId: number;
  private currentProductId: number;
  private currentSaleId: number;
  private currentSaleItemId: number;
  private currentExpenseCategoryId: number;
  private currentExpenseId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.sales = new Map();
    this.saleItems = new Map();
    this.settings = new Map();
    this.expenseCategories = new Map();
    this.expenses = new Map();
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentSaleId = 1;
    this.currentSaleItemId = 1;
    this.currentExpenseCategoryId = 1;
    this.currentExpenseId = 1;

    this.initializeData();
  }

  private initializeData() {
    // Create default admin user
    const admin: User = {
      id: this.currentUserId++,
      username: "admin",
      password: "123456",
      name: "Admin User",
      role: "admin",
      createdAt: new Date(),
    };
    this.users.set(admin.id, admin);

    // Create default categories
    const categories = [
      { name: "Telefon Aksesuarları", description: "Kılıf, şarj aleti vb." },
      { name: "Kulaklık & Ses", description: "Bluetooth kulaklık, hoparlör" },
      { name: "Şarj Ürünleri", description: "Power bank, kablo, adaptör" },
      { name: "Ekran Koruyucu", description: "Cam, film koruyucu" },
      { name: "SIM & Hat", description: "SIM kart, hat işlemleri" },
    ];

    categories.forEach(cat => {
      const category: Category = {
        id: this.currentCategoryId++,
        ...cat,
      };
      this.categories.set(category.id, category);
    });

    // Create default settings
    const defaultSettings = [
      { key: "company_name", value: "Türkcell Bayii", type: "string" },
      { key: "currency", value: "TL", type: "string" },
      { key: "tax_rate", value: "20", type: "number" },
      { key: "low_stock_threshold", value: "5", type: "number" },
    ];

    defaultSettings.forEach(setting => {
      const settingRecord: Setting = {
        id: this.settings.size + 1,
        ...setting,
      };
      this.settings.set(setting.key, settingRecord);
    });

    // Create default expense categories
    const defaultExpenseCategories = [
      { name: "Kira", description: "Mağaza kira ödemeleri", color: "#ef4444" },
      { name: "Faturalar", description: "Elektrik, su, doğalgaz", color: "#f59e0b" },
      { name: "Muhasebe", description: "Mali müşavir ücretleri", color: "#3b82f6" },
      { name: "Personel", description: "Maaş ve sosyal yardımlar", color: "#10b981" },
      { name: "Pazarlama", description: "Reklam ve tanıtım", color: "#8b5cf6" },
      { name: "Diğer", description: "Çeşitli giderler", color: "#6b7280" },
    ];

    defaultExpenseCategories.forEach(category => {
      const expenseCategoryRecord: ExpenseCategory = {
        id: this.currentExpenseCategoryId++,
        ...category,
      };
      this.expenseCategories.set(expenseCategoryRecord.id, expenseCategoryRecord);
    });

    // Create sample expenses
    const sampleExpenses = [
      {
        title: "Mağaza Kirası - Ocak",
        amount: "15000.00",
        categoryId: 1,
        userId: 1,
        dueDate: new Date(2025, 0, 5),
        isPaid: true,
        paymentDate: new Date(2025, 0, 3),
        isRecurring: true,
        recurringType: "monthly",
        notes: "Ocak ayı kira ödemesi",
      },
      {
        title: "Elektrik Faturası",
        amount: "800.00",
        categoryId: 2,
        userId: 1,
        dueDate: new Date(2025, 1, 15),
        isPaid: false,
        paymentDate: null,
        isRecurring: true,
        recurringType: "monthly",
        notes: "Ocak ayı elektrik tüketimi",
      },
      {
        title: "Mali Müşavir Ücreti",
        amount: "2500.00",
        categoryId: 3,
        userId: 1,
        dueDate: new Date(2025, 1, 10),
        isPaid: false,
        paymentDate: null,
        isRecurring: true,
        recurringType: "monthly",
        notes: "Aylık muhasebe hizmeti",
      },
    ];

    sampleExpenses.forEach(expense => {
      const expenseRecord: Expense = {
        id: this.currentExpenseId++,
        ...expense,
        createdAt: new Date(),
      };
      this.expenses.set(expenseRecord.id, expenseRecord);
    });

    // Create sample products
    const sampleProducts = [
      {
        name: "iPhone 14 Pro Kılıf",
        barcode: "8690123456789",
        categoryId: 1,
        buyPrice: "200.00",
        sellPrice: "280.00",
        stock: 15,
        minStock: 5,
        description: "Şeffaf silikon kılıf",
      },
      {
        name: "Bluetooth Kulaklık",
        barcode: "8690123456790",
        categoryId: 2,
        buyPrice: "300.00",
        sellPrice: "450.00",
        stock: 8,
        minStock: 3,
        description: "Kablosuz bluetooth kulaklık",
      },
      {
        name: "Power Bank 20000mAh",
        barcode: "8690123456791",
        categoryId: 3,
        buyPrice: "200.00",
        sellPrice: "320.00",
        stock: 12,
        minStock: 5,
        description: "Taşınabilir şarj cihazı",
      },
      {
        name: "Samsung Galaxy Kılıf",
        barcode: "8690123456792",
        categoryId: 1,
        buyPrice: "150.00",
        sellPrice: "220.00",
        stock: 2,
        minStock: 10,
        description: "Darbeye dayanıklı kılıf",
      },
      {
        name: "Şarj Kablosu Type-C",
        barcode: "8690123456793",
        categoryId: 3,
        buyPrice: "25.00",
        sellPrice: "45.00",
        stock: 5,
        minStock: 15,
        description: "USB-C şarj kablosu",
      },
    ];

    sampleProducts.forEach(prod => {
      const product: Product = {
        id: this.currentProductId++,
        ...prod,
        isActive: true,
        createdAt: new Date(),
      };
      this.products.set(product.id, product);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      id: this.currentUserId++,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async validateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (user && user.password === password) {
      return user;
    }
    return null;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const category: Category = {
      ...insertCategory,
      id: this.currentCategoryId++,
    };
    this.categories.set(category.id, category);
    return category;
  }

  async updateCategory(id: number, insertCategory: Partial<InsertCategory>): Promise<Category | undefined> {
    const existing = this.categories.get(id);
    if (!existing) return undefined;

    const updated: Category = { ...existing, ...insertCategory };
    this.categories.set(id, updated);
    return updated;
  }

  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }

  // Products
  async getProducts(): Promise<ProductWithCategory[]> {
    const products = Array.from(this.products.values());
    return products.map(product => ({
      ...product,
      category: this.categories.get(product.categoryId || 0),
    }));
  }

  async getProduct(id: number): Promise<ProductWithCategory | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    return {
      ...product,
      category: this.categories.get(product.categoryId || 0),
    };
  }

  async getProductByBarcode(barcode: string): Promise<ProductWithCategory | undefined> {
    const product = Array.from(this.products.values()).find(p => p.barcode === barcode);
    if (!product) return undefined;

    return {
      ...product,
      category: this.categories.get(product.categoryId || 0),
    };
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const product: Product = {
      ...insertProduct,
      id: this.currentProductId++,
      createdAt: new Date(),
    };
    this.products.set(product.id, product);
    return product;
  }

  async updateProduct(id: number, insertProduct: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;

    const updated: Product = { ...existing, ...insertProduct };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async updateStock(productId: number, quantity: number): Promise<boolean> {
    const product = this.products.get(productId);
    if (!product) return false;

    product.stock += quantity;
    this.products.set(productId, product);
    return true;
  }

  // Sales
  async getSales(): Promise<SaleWithItems[]> {
    const salesList = Array.from(this.sales.values());
    return salesList.map(sale => this.enrichSale(sale));
  }

  async getSale(id: number): Promise<SaleWithItems | undefined> {
    const sale = this.sales.get(id);
    if (!sale) return undefined;
    return this.enrichSale(sale);
  }

  async createSale(insertSale: InsertSale, items: InsertSaleItem[]): Promise<Sale> {
    const sale: Sale = {
      ...insertSale,
      id: this.currentSaleId++,
      createdAt: new Date(),
    };
    this.sales.set(sale.id, sale);

    // Add sale items
    items.forEach(item => {
      const saleItem: SaleItem = {
        ...item,
        id: this.currentSaleItemId++,
        saleId: sale.id,
      };
      this.saleItems.set(saleItem.id, saleItem);

      // Update product stock
      this.updateStock(item.productId, -item.quantity);
    });

    return sale;
  }

  async getSalesByDateRange(startDate: Date, endDate: Date): Promise<SaleWithItems[]> {
    const salesList = Array.from(this.sales.values()).filter(
      sale => sale.createdAt && sale.createdAt >= startDate && sale.createdAt <= endDate
    );
    return salesList.map(sale => this.enrichSale(sale));
  }

  private enrichSale(sale: Sale): SaleWithItems {
    const items = Array.from(this.saleItems.values())
      .filter(item => item.saleId === sale.id)
      .map(item => ({
        ...item,
        product: this.products.get(item.productId)!,
      }));

    return {
      ...sale,
      items,
      user: this.users.get(sale.userId || 0),
    };
  }

  // Settings
  async getSettings(): Promise<Setting[]> {
    return Array.from(this.settings.values());
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    return this.settings.get(key);
  }

  async setSetting(insertSetting: InsertSetting): Promise<Setting> {
    const existing = this.settings.get(insertSetting.key);
    const setting: Setting = {
      ...insertSetting,
      id: existing?.id || this.settings.size + 1,
    };
    this.settings.set(insertSetting.key, setting);
    return setting;
  }

  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    const products = Array.from(this.products.values());
    const sales = Array.from(this.sales.values());
    
    const totalProducts = products.length;
    const stockValue = products.reduce((sum, product) => {
      return sum + (parseFloat(product.buyPrice) * product.stock);
    }, 0);
    
    const lowStockCount = products.filter(product => product.stock <= product.minStock).length;
    
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const dailyRevenue = sales
      .filter(sale => sale.createdAt && sale.createdAt >= todayStart)
      .reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);
    
    const weeklyRevenue = sales
      .filter(sale => sale.createdAt && sale.createdAt >= weekStart)
      .reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);
    
    const monthlyRevenue = sales
      .filter(sale => sale.createdAt && sale.createdAt >= monthStart)
      .reduce((sum, sale) => sum + parseFloat(sale.totalAmount), 0);

    return {
      totalProducts,
      stockValue,
      lowStockCount,
      dailyRevenue,
      weeklyRevenue,
      monthlyRevenue,
      totalSales: sales.length,
    };
  }

  async getRecentSales(limit = 10): Promise<RecentSale[]> {
    const sales = Array.from(this.sales.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);

    return sales.map(sale => {
      const items = Array.from(this.saleItems.values()).filter(item => item.saleId === sale.id);
      const firstItem = items[0];
      const product = this.products.get(firstItem?.productId || 0);
      const profit = parseFloat(sale.totalAmount) - items.reduce((sum, item) => {
        const prod = this.products.get(item.productId);
        return sum + (parseFloat(prod?.buyPrice || "0") * item.quantity);
      }, 0);

      return {
        id: sale.id,
        productName: product?.name || "Unknown Product",
        quantity: items.reduce((sum, item) => sum + item.quantity, 0),
        totalPrice: parseFloat(sale.totalAmount),
        profit,
        createdAt: sale.createdAt || new Date(),
      };
    });
  }

  async getLowStockProducts(): Promise<ProductWithCategory[]> {
    const products = Array.from(this.products.values())
      .filter(product => product.stock <= product.minStock);
    
    return products.map(product => ({
      ...product,
      category: this.categories.get(product.categoryId || 0),
    }));
  }

  // Expense Categories
  async getExpenseCategories(): Promise<ExpenseCategory[]> {
    return Array.from(this.expenseCategories.values());
  }

  async getExpenseCategory(id: number): Promise<ExpenseCategory | undefined> {
    return this.expenseCategories.get(id);
  }

  async createExpenseCategory(insertExpenseCategory: InsertExpenseCategory): Promise<ExpenseCategory> {
    const expenseCategory: ExpenseCategory = {
      id: this.currentExpenseCategoryId++,
      name: insertExpenseCategory.name,
      description: insertExpenseCategory.description || null,
      color: insertExpenseCategory.color || null,
    };
    this.expenseCategories.set(expenseCategory.id, expenseCategory);
    return expenseCategory;
  }

  async updateExpenseCategory(id: number, insertExpenseCategory: Partial<InsertExpenseCategory>): Promise<ExpenseCategory | undefined> {
    const existing = this.expenseCategories.get(id);
    if (!existing) return undefined;

    const updated: ExpenseCategory = { ...existing, ...insertExpenseCategory };
    this.expenseCategories.set(id, updated);
    return updated;
  }

  async deleteExpenseCategory(id: number): Promise<boolean> {
    return this.expenseCategories.delete(id);
  }

  // Expenses
  async getExpenses(): Promise<ExpenseWithCategory[]> {
    const expenses = Array.from(this.expenses.values());
    return expenses.map(expense => ({
      ...expense,
      category: this.expenseCategories.get(expense.categoryId)!,
    }));
  }

  async getExpense(id: number): Promise<ExpenseWithCategory | undefined> {
    const expense = this.expenses.get(id);
    if (!expense) return undefined;

    return {
      ...expense,
      category: this.expenseCategories.get(expense.categoryId)!,
    };
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const expense: Expense = {
      id: this.currentExpenseId++,
      createdAt: new Date(),
      categoryId: insertExpense.categoryId,
      userId: insertExpense.userId || null,
      title: insertExpense.title,
      amount: insertExpense.amount,
      dueDate: insertExpense.dueDate,
      paymentDate: insertExpense.paymentDate || null,
      isPaid: insertExpense.isPaid || false,
      isRecurring: insertExpense.isRecurring || false,
      recurringType: insertExpense.recurringType || null,
      notes: insertExpense.notes || null,
    };
    this.expenses.set(expense.id, expense);
    return expense;
  }

  async updateExpense(id: number, insertExpense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const existing = this.expenses.get(id);
    if (!existing) return undefined;

    const updated: Expense = { ...existing, ...insertExpense };
    this.expenses.set(id, updated);
    return updated;
  }

  async deleteExpense(id: number): Promise<boolean> {
    return this.expenses.delete(id);
  }

  async markExpenseAsPaid(id: number): Promise<boolean> {
    const expense = this.expenses.get(id);
    if (!expense) return false;

    const updated: Expense = {
      ...expense,
      isPaid: true,
      paymentDate: new Date(),
    };
    this.expenses.set(id, updated);
    return true;
  }

  async getUpcomingExpenses(days = 7): Promise<UpcomingExpense[]> {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);

    const upcomingExpenses = Array.from(this.expenses.values())
      .filter(expense => 
        !expense.isPaid && 
        new Date(expense.dueDate) >= today && 
        new Date(expense.dueDate) <= futureDate
      )
      .map(expense => {
        const category = this.expenseCategories.get(expense.categoryId)!;
        const daysUntilDue = Math.ceil((new Date(expense.dueDate).getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        return {
          id: expense.id,
          title: expense.title,
          amount: parseFloat(expense.amount),
          dueDate: new Date(expense.dueDate),
          categoryName: category.name,
          categoryColor: category.color || '#6B7280',
          daysUntilDue,
        };
      })
      .sort((a, b) => a.daysUntilDue - b.daysUntilDue);

    return upcomingExpenses;
  }

  async getExpenseStats(): Promise<ExpenseStats> {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    const allExpenses = Array.from(this.expenses.values());

    const monthlyExpenses = allExpenses
      .filter(expense => {
        const expenseDate = new Date(expense.dueDate);
        return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear;
      })
      .reduce((sum, expense) => sum + parseFloat(expense.amount), 0);

    const yearlyExpenses = allExpenses
      .filter(expense => {
        const expenseDate = new Date(expense.dueDate);
        return expenseDate.getFullYear() === currentYear;
      })
      .reduce((sum, expense) => sum + parseFloat(expense.amount), 0);

    const pendingPayments = allExpenses.filter(expense => !expense.isPaid).length;
    const overduePayments = allExpenses.filter(expense => 
      !expense.isPaid && new Date(expense.dueDate) < today
    ).length;

    return {
      totalMonthlyExpenses: monthlyExpenses,
      totalYearlyExpenses: yearlyExpenses,
      pendingPayments,
      overduePayments,
    };
  }
}

// Initialize storage with database or fallback to memory
export const storage = process.env.DATABASE_URL ? new DbStorage() : new MemStorage();
