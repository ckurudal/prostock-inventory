# ProStock - Türkcell Bayii Stok Takip Sistemi
## Kurulum Klavuzu

### 📋 Sistem Gereksinimleri
- **Node.js**: v18 veya üzeri
- **PostgreSQL**: v13 veya üzeri
- **Git**: En son sürüm
- **Web Tarayıcı**: Chrome, Firefox, Safari, Edge

---

### 🚀 Adım 1: Proje Dosyalarını İndirin

```bash
# Projeyi klonlayın
git clone [PROJE_URL]
cd prostock

# Veya ZIP dosyasını indirip çıkarın
```

---

### 🛠 Adım 2: Bağımlılıkları Yükleyin

```bash
# Node.js bağımlılıklarını yükleyin
npm install

# Kurulum tamamlandığında şu mesajı görmelisiniz:
# "added xxx packages"
```

---

### 🗄️ Adım 3: PostgreSQL Veritabanını Kurun

#### Windows için:
1. PostgreSQL'i resmi siteden indirin: https://www.postgresql.org/download/
2. Kurulum sırasında şifre belirleyin (örn: `123456`)
3. Port: `5432` (varsayılan)

#### macOS için:
```bash
# Homebrew ile kurulum
brew install postgresql
brew services start postgresql

# Veritabanı kullanıcısı oluşturun
createdb prostock_db
```

#### Linux için:
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib

# Servis başlatın
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

---

### ⚙️ Adım 4: Çevre Değişkenlerini Ayarlayın

Proje kök dizininde `.env` dosyası oluşturun:

```bash
# .env dosyası
DATABASE_URL="postgresql://username:password@localhost:5432/prostock_db"
NODE_ENV=development
PORT=5000

# PostgreSQL ayarları
PGHOST=localhost
PGPORT=5432
PGUSER=postgres
PGPASSWORD=123456
PGDATABASE=prostock_db
```

**Önemli:** `username`, `password` ve `prostock_db` değerlerini kendi PostgreSQL ayarlarınıza göre değiştirin.

---

### 📊 Adım 5: Veritabanı Tablolarını Oluşturun

```bash
# Veritabanı migrasyonlarını çalıştırın
npx drizzle-kit generate
npx drizzle-kit migrate

# Bu komutlar aşağıdaki tabloları oluşturacak:
# - users (kullanıcılar)
# - categories (kategoriler) 
# - products (ürünler)
# - sales (satışlar)
# - sale_items (satış kalemleri)
# - settings (ayarlar)
```

---

### 📦 Adım 6: Demo Verilerini Yükleyin

PostgreSQL veritabanınıza bağlanıp aşağıdaki SQL komutlarını çalıştırın:

```sql
-- Demo kullanıcı
INSERT INTO users (username, password, name, role) 
VALUES ('admin', '123456', 'Bayii Admin', 'admin');

-- Demo kategoriler
INSERT INTO categories (name, description) VALUES 
('Telefon Aksesuarları', 'Kılıf, şarj cihazı ve diğer telefon aksesuarları'),
('Kulaklık & Ses', 'Kulaklık, hoparlör ve ses cihazları'),
('Tablet & Bilgisayar', 'Tablet, laptop ve bilgisayar aksesuarları'),
('Şarj Cihazları', 'Kablosuz ve kablolu şarj cihazları'),
('Akıllı Saat', 'Akıllı saat ve kordon aksesuarları');

-- Demo ürünler
INSERT INTO products (name, barcode, description, category_id, buy_price, sell_price, stock, min_stock, is_active) VALUES 
('iPhone 14 Pro Kılıf', '8690123456789', 'Şeffaf silikon kılıf', 1, '25.00', '45.00', 15, 5, true),
('Samsung AirPods', '8690234567890', 'Kablosuz kulaklık', 2, '180.00', '220.00', 8, 3, true),
('iPad Koruyucu Film', '8690345678901', 'Temperli cam ekran koruyucu', 3, '35.00', '55.00', 12, 5, true),
('Samsung Galaxy Kılıf', '8690456789012', 'Darbeye dayanıklı kılıf', 1, '30.00', '50.00', 3, 5, true),
('Wireless Şarj Cihazı', '8690567890123', '15W kablosuz şarj pad', 4, '85.00', '120.00', 6, 4, true);

-- Demo ayarlar
INSERT INTO settings (key, value, type) VALUES 
('store_name', 'Türkcell Bayii Mağaza', 'string'),
('store_address', 'Atatürk Cad. No:123 Ankara', 'string'),
('store_phone', '+90 312 123 45 67', 'string'),
('tax_rate', '18', 'number'),
('currency', 'TL', 'string');
```

---

### 🎯 Adım 7: Uygulamayı Başlatın

```bash
# Development modunda başlatın
npm run dev

# Terminal çıktısı:
# "serving on port 5000"
# "vite dev server running"
```

---

### 🌐 Adım 8: Uygulamaya Erişin

1. Web tarayıcınızı açın
2. `http://localhost:5000` adresine gidin
3. Giriş bilgileri:
   - **Kullanıcı adı:** `admin`
   - **Şifre:** `123456`

---

### ✅ Sistem Kontrolü

Giriş yaptıktan sonra kontrol edin:

- [ ] Dashboard istatistikleri yükleniyor mu?
- [ ] Sol menüden sayfalara geçiş yapabiliyor musunuz?
- [ ] Ürünler sayfasında 5 demo ürün görünüyor mu?
- [ ] Bildirim ikonu çalışıyor mu?
- [ ] Mobil menü (3 çizgi) açılıyor mu?

---

### 🔧 Sorun Giderme

#### Veritabanı Bağlantı Hatası:
```bash
# PostgreSQL servisinin çalıştığını kontrol edin
# Windows: services.msc → PostgreSQL
# macOS: brew services list
# Linux: systemctl status postgresql
```

#### Port Hatası (Port 5000 kullanımda):
`.env` dosyasında `PORT=3000` olarak değiştirin.

#### Migration Hatası:
```bash
# Veritabanını sıfırlayın
dropdb prostock_db
createdb prostock_db

# Migration'ları tekrar çalıştırın
npx drizzle-kit migrate
```

---

### 📱 Özellikler

- **Dashboard:** Stok istatistikleri ve özet bilgiler
- **Ürün Yönetimi:** Ekleme, düzenleme, silme, kategori filtreleme
- **Barkod Sistemi:** Okuma ve oluşturma
- **Satış Noktası:** Sepet yönetimi ve satış işlemi
- **Raporlama:** Grafik ve tablo formatında raporlar
- **Bildirimler:** Düşük stok uyarıları
- **Ayarlar:** Mağaza bilgileri ve sistem konfigürasyonu
- **Responsive Tasarım:** Mobil ve masaüstü uyumlu
- **Karanlık Mod:** Tema değiştirme özelliği

---

### 🚀 Üretim Kurulumu (Production)

```bash
# Üretim versiyonu oluşturun
npm run build

# PM2 ile servis olarak çalıştırın
npm install -g pm2
pm2 start npm --name "prostock" -- start

# Nginx ile reverse proxy (opsiyonel)
# /etc/nginx/sites-available/prostock
```

---

### 📞 Destek

Kurulum sırasında sorun yaşarsanız:

1. Terminal çıktılarını kontrol edin
2. `.env` dosyasının doğru yapılandırıldığından emin olun
3. PostgreSQL servisinin çalıştığını kontrol edin
4. Firewall ayarlarını kontrol edin (port 5000)

**ProStock - Profesyonel Stok Takip Sistemi** 🎉